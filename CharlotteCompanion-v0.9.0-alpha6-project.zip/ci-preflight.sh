#!/usr/bin/env bash
set -euo pipefail

test -f gradle.properties
grep -q "android.useAndroidX=true" gradle.properties

test -f app/src/main/AndroidManifest.xml
test -f app/src/main/java/com/charlotte/companion/remote/AiGatewayClient.kt
test -f app/src/main/java/com/charlotte/companion/overlay/ConversationOverlayService.kt

grep -q 'applicationId = "com.charlotte.companion"' app/build.gradle.kts
grep -q 'versionName = "0.9.0-alpha6"' app/build.gradle.kts
grep -q 'btnTestApi' app/src/main/res/layout/activity_main.xml
grep -q 'fun test(model: String)' app/src/main/java/com/charlotte/companion/remote/AiGatewayClient.kt
grep -q 'generativelanguage.googleapis.com' app/src/main/java/com/charlotte/companion/remote/AiGatewayClient.kt

echo "PRECHECK=PASS"
