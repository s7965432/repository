# Third-party notices

## sherpa-onnx
Project: https://github.com/k2-fsa/sherpa-onnx
Used for on-device ZipVoice TTS/voice cloning runtime.

## ZipVoice model
Downloaded at runtime from the official sherpa-onnx release:
`sherpa-onnx-zipvoice-distill-int8-zh-en-emilia.tar.bz2`

## Vocos
Downloaded at runtime from the official sherpa-onnx vocoder release:
`vocos_24khz.onnx`

The application does not claim ownership of third-party models or runtimes.
Their original licenses and terms continue to apply.
