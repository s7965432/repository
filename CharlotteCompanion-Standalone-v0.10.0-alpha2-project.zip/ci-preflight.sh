#!/usr/bin/env bash
set -euo pipefail

test -f gradle.properties
grep -q "android.useAndroidX=true" gradle.properties

test -f app/src/main/java/com/charlotte/companion/voice/ZipVoiceModelManager.kt
test -f app/src/main/java/com/charlotte/companion/voice/ZipVoiceCloneEngine.kt
test -f app/src/main/java/com/charlotte/companion/voice/ReferenceVoiceCapture.kt
test -f app/src/main/java/com/charlotte/companion/voice/ReferenceAudioTranscriber.kt
test -f app/src/main/java/com/charlotte/companion/voice/WavUtil.kt

grep -q 'applicationId = "com.charlotte.companion"' app/build.gradle.kts
grep -q 'versionName = "0.10.0-alpha2"' app/build.gradle.kts
grep -q 'sherpa-onnx-1.13.7.aar' app/build.gradle.kts

grep -q 'btnStopWatch' app/src/main/res/layout/activity_main.xml
grep -q 'btnDownloadVoiceModel' app/src/main/res/layout/activity_main.xml
grep -q 'ACTION_STOP_WATCH' app/src/main/java/com/charlotte/companion/watch/ScreenWatchService.kt
grep -q 'MediaProjection' app/src/main/java/com/charlotte/companion/watch/ScreenWatchService.kt
grep -q 'OfflineTtsZipVoiceModelConfig' app/src/main/java/com/charlotte/companion/voice/ZipVoiceCloneEngine.kt

test -f app/libs/sherpa-onnx-1.13.7.aar

echo "PRECHECK=PASS"
