# 夏洛特共用手機模式 — Standalone v0.10.0-alpha2

這版直接修正兩個實機問題：

1. **觀看服務不能直接關閉**
   - 主畫面新增「停止保持觀看」
   - 懸浮對話新增「停止保持觀看」
   - 前景通知新增「停止觀看」
   - 會真的 `MediaProjection.stop()`、釋放 VirtualDisplay / ImageReader、停止前景服務
   - 不需要再去 Android 應用程式頁強制停止

2. **聲音不是只靠音調/高低音**
   - 移除把「音高 + 語速」當成音色學習的做法
   - 改成保存角色的真實參考 WAV
   - 使用 sherpa-onnx ZipVoice 零樣本 voice cloning
   - 參考音訊會直接參與生成，因此會學聲音音色，而不是只調 TTS pitch/rate
   - 模型是中英雙語 ZipVoice INT8
   - 一次下載約 165 MB（ZipVoice 約 109 MB + Vocos 約 54 MB）
   - 模型與推理都留在手機本機

## 聲音學習流程

1. 按「下載音色模型（約 165 MB，一次）」
2. 按「開始保持觀看」
3. 打開目標 App，讓想學的角色單獨說話
4. 按「開始擷取角色原聲（5～15 秒）」
5. 播 5～15 秒乾淨角色台詞
6. 按「停止並保存角色原聲」
7. Android 13+ 會嘗試把保存的 PCM 直接送進系統 SpeechRecognizer，自動取得參考台詞
8. 若自動辨識不準，可回主畫面修正「角色參考台詞」
9. 按「語音輸出測試」

ZipVoice 需要「參考音訊 + 對應台詞」，兩者越準確，音色複製越穩。

## 限制

- 目標 App 若禁止 Android AudioPlaybackCapture，就抓不到內部角色聲音。
- 背景音樂、音效、多人同時說話都會污染參考音色；最好抓乾淨單人台詞。
- ZipVoice 此模型主要支援中文與英文。
- 請只對你有權使用或獲准使用的聲音做參考合成；不要拿來冒充真人或欺騙他人。

## 第三方

- sherpa-onnx 1.13.7
- ZipVoice zh/en INT8 model
- Vocos 24 kHz vocoder

模型下載來源為 k2-fsa/sherpa-onnx 官方 releases。
