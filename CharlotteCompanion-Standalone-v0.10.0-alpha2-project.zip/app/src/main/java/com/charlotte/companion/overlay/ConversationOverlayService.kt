package com.charlotte.companion.overlay

import android.Manifest
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.*
import android.view.Gravity
import android.view.WindowManager
import android.widget.*
import androidx.core.content.ContextCompat
import com.charlotte.companion.agent.CharlotteAgentLoop
import com.charlotte.companion.model.ActionType
import com.charlotte.companion.model.RiskLevel
import com.charlotte.companion.state.CharlotteStateStore
import com.charlotte.companion.voice.SpeechOutputController
import kotlinx.coroutines.*

class ConversationOverlayService : Service(), RecognitionListener {

    private lateinit var windowManager: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var messageView: TextView
    private lateinit var statusView: TextView
    private lateinit var micButton: Button
    private lateinit var continuousButton: Button
    private lateinit var actionButton: Button

    private var recognizer: SpeechRecognizer? = null
    private lateinit var speech: SpeechOutputController
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())

    private var lastSpokenMessage = ""
    private var isListening = false
    private var awaitingVoiceAnswer = false

    override fun onCreate() {
        super.onCreate()
        CharlotteStateStore.conversationOpen = true
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        speech = SpeechOutputController(this)

        messageView = TextView(this).apply {
            text = "夏洛特：${CharlotteStateStore.thought.value.message}"
            textSize = 17f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 0, 0, 10)
        }

        statusView = TextView(this).apply {
            text = CharlotteStateStore.aiStatus.value
            textSize = 12f
            setTextColor(0xFFBDBDBD.toInt())
            setPadding(0, 0, 0, 12)
        }

        micButton = Button(this).apply {
            text = "🎙 說話"
            setOnClickListener {
                speech.interrupt()
                startVoice()
            }
        }

        continuousButton = Button(this).apply {
            text = if (CharlotteStateStore.continuousVoice) {
                "🔁 連續語音：開"
            } else {
                "🔁 連續語音：關"
            }
            setOnClickListener {
                CharlotteStateStore.continuousVoice = !CharlotteStateStore.continuousVoice
                text = if (CharlotteStateStore.continuousVoice) {
                    "🔁 連續語音：開"
                } else {
                    "🔁 連續語音：關"
                }
                if (CharlotteStateStore.continuousVoice) {
                    speech.interrupt()
                    startVoice()
                } else {
                    recognizer?.cancel()
                    isListening = false
                    micButton.text = "🎙 說話"
                }
            }
        }

        actionButton = Button(this).apply {
            text = "讓夏洛特做"
            setOnClickListener {
                val action = CharlotteStateStore.pendingAction
                when {
                    action == null || action.type == ActionType.NONE -> {
                        Toast.makeText(
                            this@ConversationOverlayService,
                            "目前沒有待執行動作",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                    action.risk == RiskLevel.HIGH -> {
                        Toast.makeText(
                            this@ConversationOverlayService,
                            "這個動作被標記為高風險，不直接執行",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                    else -> {
                        val ok = CharlotteAgentLoop.executePendingAction(applicationContext)
                        Toast.makeText(
                            this@ConversationOverlayService,
                            if (ok) "已執行" else "操作權限尚未啟用",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
        }

        val minimize = Button(this).apply {
            text = "縮回夏洛特"
            setOnClickListener { stopSelf() }
        }

        val closeOverlay = Button(this).apply {
            text = "關閉懸浮夏洛特"
            setOnClickListener {
                stopService(
                    Intent(
                        this@ConversationOverlayService,
                        OverlayBubbleService::class.java
                    )
                )
                stopSelf()
            }
        }

        val stopWatching = Button(this).apply {
            text = "停止保持觀看"
            setOnClickListener {
                startService(
                    Intent(
                        this@ConversationOverlayService,
                        com.charlotte.companion.watch.ScreenWatchService::class.java
                    ).apply {
                        action =
                            com.charlotte.companion.watch.ScreenWatchService.ACTION_STOP_WATCH
                    }
                )
            }
        }

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
            setBackgroundColor(0xEE151515.toInt())
            addView(messageView)
            addView(statusView)
            addView(micButton)
            addView(continuousButton)
            addView(actionButton)
            addView(minimize)
            addView(stopWatching)
            addView(closeOverlay)
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM
        }

        windowManager.addView(root, params)

        scope.launch {
            CharlotteStateStore.aiStatus.collect {
                statusView.text = it
            }
        }

        scope.launch {
            CharlotteStateStore.thought.collect { thought ->
                messageView.text = "夏洛特：${thought.message}"
                val action = thought.action
                actionButton.isEnabled =
                    action != null &&
                    action.type != ActionType.NONE &&
                    action.risk != RiskLevel.HIGH

                val shouldSpeak = thought.speak &&
                    thought.message.isNotBlank() &&
                    thought.message != lastSpokenMessage

                if (shouldSpeak) {
                    lastSpokenMessage = thought.message
                    awaitingVoiceAnswer = false
                    speech.speak(thought.message) {
                        handler.post {
                            if (CharlotteStateStore.continuousVoice) {
                                handler.postDelayed({ startVoice() }, 350)
                            }
                        }
                    }
                } else if (awaitingVoiceAnswer && CharlotteStateStore.continuousVoice) {
                    awaitingVoiceAnswer = false
                    handler.postDelayed({ startVoice() }, 450)
                }
            }
        }
    }

    private fun startVoice() {
        if (isListening) return

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            messageView.text = "夏洛特：先回主畫面允許麥克風權限，我才能聽你說話。"
            return
        }

        speech.interrupt()

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            messageView.text = "夏洛特：這支手機目前沒有可用的語音辨識服務。"
            return
        }

        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
                it.setRecognitionListener(this)
            }
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "zh-TW")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }

        isListening = true
        micButton.text = "正在聽…"
        recognizer?.startListening(intent)
    }

    override fun onReadyForSpeech(params: Bundle?) {
        micButton.text = "我在聽"
    }

    override fun onBeginningOfSpeech() = Unit
    override fun onRmsChanged(rmsdB: Float) = Unit
    override fun onBufferReceived(buffer: ByteArray?) = Unit

    override fun onEndOfSpeech() {
        micButton.text = "處理中…"
    }

    override fun onError(error: Int) {
        isListening = false

        val label = when (error) {
            SpeechRecognizer.ERROR_NO_MATCH,
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "沒聽到，按一下再說"
            SpeechRecognizer.ERROR_NETWORK,
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "語音辨識網路錯誤"
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "麥克風權限不足"
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "語音辨識忙碌，稍後重試"
            else -> "語音辨識錯誤：$error"
        }

        micButton.text = "🎙 $label"

        // 不再用語音辨識錯誤覆蓋夏洛特真正的 AI 訊息。
        if (CharlotteStateStore.continuousVoice) {
            handler.postDelayed({ startVoice() }, 900)
        }
    }

    override fun onResults(results: Bundle?) {
        isListening = false
        micButton.text = "🎙 說話"

        val text = results
            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            ?.firstOrNull()
            .orEmpty()
            .trim()

        if (text.isNotBlank()) {
            messageView.text = "你：$text\n\n夏洛特：我在想。"
            awaitingVoiceAnswer = true
            CharlotteAgentLoop.onUserVoice(applicationContext, text)
        } else if (CharlotteStateStore.continuousVoice) {
            handler.postDelayed({ startVoice() }, 600)
        }
    }

    override fun onPartialResults(partialResults: Bundle?) {
        val partial = partialResults
            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            ?.firstOrNull()
            .orEmpty()

        if (partial.isNotBlank()) {
            messageView.text = "你：$partial"
        }
    }

    override fun onEvent(eventType: Int, params: Bundle?) = Unit

    override fun onDestroy() {
        CharlotteStateStore.conversationOpen = false
        CharlotteStateStore.continuousVoice = false
        scope.cancel()
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        speech.shutdown()
        runCatching { windowManager.removeView(root) }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
