package com.charlotte.companion.watch

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import com.charlotte.companion.agent.CharlotteAgentLoop
import com.charlotte.companion.state.CharlotteStateStore
import com.charlotte.companion.voice.ReferenceVoiceCapture
import com.charlotte.companion.voice.ReferenceAudioTranscriber
import com.charlotte.companion.voice.VoiceCloneStore

class ScreenWatchService : Service() {

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private lateinit var captureThread: HandlerThread
    private lateinit var captureHandler: Handler
    private var lastEncodedAt = 0L
    private var voiceCapture: ReferenceVoiceCapture? = null

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            CharlotteStateStore.updateWatching(false)
            stopSelf()
        }
    }

    override fun onCreate() {
        super.onCreate()
        captureThread = HandlerThread("CharlotteCapture").apply { start() }
        captureHandler = Handler(captureThread.looper)

        val channel = NotificationChannel(
            "charlotte_watch",
            "夏洛特持續觀看",
            NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(channel)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_WATCH -> {
                voiceCapture?.stop()
                voiceCapture = null
                CharlotteStateStore.updateVoiceLearning(false)
                CharlotteStateStore.updateVoiceLearningStatus("已停止觀看與聲音學習")
                CharlotteStateStore.updateWatching(false)
                releaseCapture()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }

            ACTION_START_VOICE_LEARNING -> {
                val mp = projection
                if (mp == null) {
                    CharlotteStateStore.updateVoiceLearningStatus(
                        "先按「開始保持觀看」"
                    )
                } else {
                    voiceCapture?.stop()

                    voiceCapture = ReferenceVoiceCapture(
                        context = applicationContext,
                        projection = mp
                    ) { pcm, _, sampleRate ->
                        CharlotteStateStore.updateVoiceLearningStatus(
                            "原聲已保存，正在自動辨識角色台詞…"
                        )

                        android.os.Handler(android.os.Looper.getMainLooper()).post {
                            ReferenceAudioTranscriber(applicationContext).transcribe(
                                pcmFile = pcm,
                                sampleRate = sampleRate,
                                onResult = { text ->
                                    VoiceCloneStore.setReferenceText(
                                        applicationContext,
                                        text
                                    )
                                    CharlotteStateStore.updateVoiceLearningStatus(
                                        "已學到原聲與台詞：$text"
                                    )
                                },
                                onError = { error ->
                                    CharlotteStateStore.updateVoiceLearningStatus(
                                        "$error；可在主畫面手動修正參考台詞"
                                    )
                                }
                            )
                        }
                    }

                    voiceCapture?.start()
                }
                return START_STICKY
            }

            ACTION_STOP_VOICE_LEARNING -> {
                voiceCapture?.stop()
                voiceCapture = null
                CharlotteStateStore.updateVoiceLearning(false)
                CharlotteStateStore.updateVoiceLearningStatus(
                    "角色原聲已保存，正在整理/辨識"
                )
                return START_STICKY
            }
        }

        val stopIntent = Intent(this, ScreenWatchService::class.java).apply {
            action = ACTION_STOP_WATCH
        }
        val stopPending = PendingIntent.getService(
            this,
            901,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        startForeground(
            10,
            Notification.Builder(this, "charlotte_watch")
                .setContentTitle("夏洛特正在持續觀看")
                .setContentText("共用手機模式運作中")
                .setSmallIcon(android.R.drawable.presence_video_online)
                .addAction(
                    Notification.Action.Builder(
                        android.R.drawable.ic_media_pause,
                        "停止觀看",
                        stopPending
                    ).build()
                )
                .build()
        )

        val resultCode = intent?.getIntExtra("resultCode", 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra("data", Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra<Intent>("data")
        }

        if (resultCode == 0 || data == null) return START_NOT_STICKY

        releaseCapture()

        val manager =
            getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        projection = manager.getMediaProjection(resultCode, data).also {
            it.registerCallback(projectionCallback, captureHandler)
        }

        createCaptureSurface()
        CharlotteStateStore.updateWatching(true)
        return START_STICKY
    }

    private fun createCaptureSurface() {
        display?.release()
        imageReader?.close()

        val dm = resources.displayMetrics
        imageReader = ImageReader.newInstance(
            dm.widthPixels,
            dm.heightPixels,
            PixelFormat.RGBA_8888,
            2
        )

        imageReader?.setOnImageAvailableListener({ reader ->
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val now = SystemClock.elapsedRealtime()
                if (now - lastEncodedAt >= 1000L) {
                    lastEncodedAt = now
                    FrameEncoder.toJpegBase64(
                        image = image,
                        maxWidth = 640,
                        quality = 62
                    )?.let {
                        CharlotteAgentLoop.onFrame(applicationContext, it)
                    }
                }
            } finally {
                image.close()
            }
        }, captureHandler)

        display = projection?.createVirtualDisplay(
            "CharlotteWatch",
            dm.widthPixels,
            dm.heightPixels,
            dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            captureHandler
        )
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        captureHandler.postDelayed({ createCaptureSurface() }, 250)
    }

    private fun releaseCapture() {
        display?.release()
        display = null
        imageReader?.close()
        imageReader = null

        projection?.let {
            runCatching { it.unregisterCallback(projectionCallback) }
            runCatching { it.stop() }
        }
        projection = null
    }

    override fun onDestroy() {
        CharlotteStateStore.updateWatching(false)
        voiceCapture?.stop();voiceCapture=null
        releaseCapture()
        if (::captureThread.isInitialized) captureThread.quitSafely()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
    companion object {
        const val ACTION_START_VOICE_LEARNING =
            "com.charlotte.companion.action.START_VOICE_LEARNING"
        const val ACTION_STOP_VOICE_LEARNING =
            "com.charlotte.companion.action.STOP_VOICE_LEARNING"
        const val ACTION_STOP_WATCH =
            "com.charlotte.companion.action.STOP_WATCH"
    }
}
