package com.charlotte.companion.ui

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.charlotte.companion.databinding.ActivityMainBinding
import com.charlotte.companion.model.AgentMode
import com.charlotte.companion.overlay.OverlayBubbleService
import com.charlotte.companion.prefs.CharlottePrefs
import com.charlotte.companion.state.CharlotteStateStore
import com.charlotte.companion.remote.AiGatewayClient
import com.charlotte.companion.voice.SpeechOutputController
import com.charlotte.companion.voice.VoiceCloneStore
import com.charlotte.companion.voice.ZipVoiceModelManager
import com.charlotte.companion.watch.ScreenWatchService
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var projectionManager: MediaProjectionManager
    private lateinit var speech: SpeechOutputController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        projectionManager =
            getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        speech = SpeechOutputController(this)

        binding.etGateway.setText(CharlottePrefs.getApiKey(this))
        binding.etReferenceText.setText(
            VoiceCloneStore.referenceText(this)
        )
        binding.tvVoiceModelStatus.text =
            if (ZipVoiceModelManager.isReady(this)) {
                "音色模型：已安裝，可以複製音色"
            } else {
                "音色模型：尚未安裝"
            }

        when (CharlottePrefs.getMode(this)) {
            AgentMode.OBSERVE -> binding.modeObserve.isChecked = true
            AgentMode.ASSIST -> binding.modeAssist.isChecked = true
            AgentMode.AUTO -> binding.modeAuto.isChecked = true
        }

        requestRuntimePermissions()

        lifecycleScope.launch {
            CharlotteStateStore.aiStatus.collect {
                binding.tvAiStatus.text = "AI：$it"
            }
        }

        lifecycleScope.launch {
            CharlotteStateStore.watching.collect {
                if (it) binding.tvStatus.text = "狀態：保持觀看中"
            }
        }

        lifecycleScope.launch {
            CharlotteStateStore.voiceLearningStatus.collect {
                binding.tvVoiceLearningStatus.text = "聲音學習：$it"
                val savedText = VoiceCloneStore.referenceText(this@MainActivity)
                if (savedText.isNotBlank() &&
                    binding.etReferenceText.text?.toString() != savedText
                ) {
                    binding.etReferenceText.setText(savedText)
                }
            }
        }

        binding.btnOverlay.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
                binding.tvStatus.text =
                    "狀態：請允許「顯示在其他應用程式上層」後再按一次"
            } else {
                ContextCompat.startForegroundService(
                    this,
                    Intent(this, OverlayBubbleService::class.java)
                )
                binding.tvStatus.text = "狀態：懸浮夏洛特已啟動"
            }
        }

        binding.btnWatch.setOnClickListener {
            startActivityForResult(
                projectionManager.createScreenCaptureIntent(),
                1001
            )
        }

        binding.btnStopWatch.setOnClickListener {
            ContextCompat.startForegroundService(
                this,
                Intent(this, ScreenWatchService::class.java).apply {
                    action = ScreenWatchService.ACTION_STOP_WATCH
                }
            )
            binding.tvStatus.text = "狀態：已停止保持觀看"
        }

        binding.btnAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        binding.btnSaveGateway.setOnClickListener {
            CharlottePrefs.setApiKey(
                this,
                binding.etGateway.text?.toString().orEmpty()
            )
            CharlottePrefs.setModels(
                this,
                CharlottePrefs.DEFAULT_WATCH_MODEL,
                CharlottePrefs.DEFAULT_DEEP_MODEL
            )
            Toast.makeText(this, "AI 連線已儲存", Toast.LENGTH_SHORT).show()
        }

        binding.btnTestApi.setOnClickListener {
            val key = binding.etGateway.text?.toString().orEmpty().trim()
            if (key.isBlank()) {
                binding.tvAiStatus.text = "AI：先填入 Gemini API Key"
                return@setOnClickListener
            }

            CharlottePrefs.setApiKey(this, key)
            binding.tvAiStatus.text = "AI：正在測試 Gemini API…"

            lifecycleScope.launch {
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        AiGatewayClient(key).test(
                            listOf(
                                CharlottePrefs.DEFAULT_WATCH_MODEL,
                                "gemini-3.1-flash-lite",
                                "gemini-3-flash-preview"
                            )
                        )
                    }
                }

                result.onSuccess { tested ->
                    CharlottePrefs.setModels(
                        this@MainActivity,
                        tested.chosenModel,
                        CharlottePrefs.DEFAULT_DEEP_MODEL
                    )
                    CharlotteStateStore.updateLastError("")
                    CharlotteStateStore.updateAiStatus("AI 測試成功 · ${tested.chosenModel}")
                    binding.tvAiStatus.text =
                        "AI：測試成功 · ${tested.chosenModel}，可以開始保持觀看"
                }.onFailure { error ->
                    val raw = error.message.orEmpty()
                    val readable = when {
                        "HTTP 401" in raw -> "401：API Key 無效"
                        "HTTP 403" in raw && "denied access" in raw.lowercase() ->
                            "403：Google 專案被拒絕使用 Gemini API"
                        "HTTP 403" in raw ->
                            "403：API Key 或專案沒有 Gemini API 權限"
                        "HTTP 404" in raw -> "404：模型在此專案不可用"
                        "HTTP 429" in raw -> "429：免費配額或速率已達上限"
                        else -> raw.take(220).ifBlank { "未知錯誤" }
                    }
                    CharlotteStateStore.updateLastError(readable)
                    CharlotteStateStore.updateAiStatus("AI 測試失敗：$readable")
                    binding.tvAiStatus.text = "AI：測試失敗：$readable"
                }
            }
        }

        binding.modeGroup.setOnCheckedChangeListener { _, checkedId ->
            val mode = when (checkedId) {
                binding.modeObserve.id -> AgentMode.OBSERVE
                binding.modeAuto.id -> AgentMode.AUTO
                else -> AgentMode.ASSIST
            }
            CharlottePrefs.setMode(this, mode)
        }


        binding.btnDownloadVoiceModel.setOnClickListener {
            binding.tvVoiceModelStatus.text = "音色模型：準備下載…"
            lifecycleScope.launch {
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        ZipVoiceModelManager.install(
                            applicationContext
                        ) { status ->
                            runOnUiThread {
                                binding.tvVoiceModelStatus.text =
                                    "音色模型：$status"
                            }
                        }
                    }
                }

                result.onSuccess {
                    binding.tvVoiceModelStatus.text =
                        "音色模型：已安裝，可以複製音色"
                }.onFailure {
                    binding.tvVoiceModelStatus.text =
                        "音色模型：失敗：${it.message?.take(180)}"
                }
            }
        }

        binding.btnSaveReferenceText.setOnClickListener {
            val text = binding.etReferenceText.text?.toString().orEmpty()
            VoiceCloneStore.setReferenceText(this, text)
            binding.tvVoiceLearningStatus.text =
                if (text.isBlank()) {
                    "聲音學習：參考台詞不能空白"
                } else {
                    "聲音學習：參考台詞已保存"
                }
        }

        binding.btnStartVoiceLearning.setOnClickListener {
            if(!CharlotteStateStore.watching.value){
                binding.tvVoiceLearningStatus.text="聲音學習：先按「開始保持觀看」"
            }else{
                ContextCompat.startForegroundService(this,Intent(this,ScreenWatchService::class.java).apply{
                    action=ScreenWatchService.ACTION_START_VOICE_LEARNING
                })
            }
        }

        binding.btnStopVoiceLearning.setOnClickListener {
            ContextCompat.startForegroundService(this,Intent(this,ScreenWatchService::class.java).apply{
                action=ScreenWatchService.ACTION_STOP_VOICE_LEARNING
            })
        }

        binding.btnVoiceDemo.setOnClickListener {
            speech.speak("我在。這次不是只改音高和語速；如果角色原聲與音色模型都準備好，我會用參考音色合成這句話。")
        }
    }

    private fun requestRuntimePermissions() {
        val needed = mutableListOf<String>()

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            needed += Manifest.permission.RECORD_AUDIO
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            needed += Manifest.permission.POST_NOTIFICATIONS
        }

        if (needed.isNotEmpty()) {
            requestPermissions(needed.toTypedArray(), 2001)
        }
    }

    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == 1001 &&
            resultCode == Activity.RESULT_OK &&
            data != null
        ) {
            val serviceIntent = Intent(
                this,
                ScreenWatchService::class.java
            ).apply {
                putExtra("resultCode", resultCode)
                putExtra("data", data)
            }

            ContextCompat.startForegroundService(this, serviceIntent)
            binding.tvStatus.text = "狀態：保持觀看中"
        } else if (requestCode == 1001) {
            Toast.makeText(
                this,
                "你取消了保持觀看",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    override fun onDestroy() {
        speech.shutdown()
        super.onDestroy()
    }
}
