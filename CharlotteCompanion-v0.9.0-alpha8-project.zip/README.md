# 夏洛特共用手機模式 v0.9.0-alpha8

alpha8 修正 alpha7 實機顯示的：

`404：模型在此專案不可用`

## 原因
alpha7 硬綁 Gemini 2.5 模型。不同 Google AI Studio 專案可見模型可能不同，
所以即使 Key 本身有效，也可能因模型不可用直接 404。

## alpha8 修正
- 不再只相信硬編碼模型名稱
- 先呼叫 Gemini `models.list`
- 只選這個 API Key / 專案實際可用、支援 `generateContent` 的模型
- 常駐視線優先：
  1. `gemini-3.1-flash-lite`
  2. `gemini-3-flash-preview`
- 深入對話優先：
  1. `gemini-3-flash-preview`
  2. `gemini-3.1-flash-lite`
- 如果首選不可用，自動選專案裡真的可用的 Flash 模型
- 「測試 AI 連線」會顯示實際選中的模型
- 不再使用 Gemini 2.5 作為預設
- 保留 alpha7 的懸浮 × 關閉、語音、錯誤顯示、持續觀看

## 測試
貼 Key → 儲存 → 測試 AI 連線。
只有 models.list 與 generateContent 都成功才顯示測試成功。
