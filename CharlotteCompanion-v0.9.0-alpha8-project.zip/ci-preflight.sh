#!/usr/bin/env bash
set -euo pipefail

test -f gradle.properties
grep -q "android.useAndroidX=true" gradle.properties

test -f app/src/main/AndroidManifest.xml
test -f app/src/main/java/com/charlotte/companion/remote/AiGatewayClient.kt

grep -q 'applicationId = "com.charlotte.companion"' app/build.gradle.kts
grep -q 'versionName = "0.9.0-alpha8"' app/build.gradle.kts
grep -q 'gemini-3.1-flash-lite' app/src/main/java/com/charlotte/companion/prefs/CharlottePrefs.kt
grep -q 'gemini-3-flash-preview' app/src/main/java/com/charlotte/companion/prefs/CharlottePrefs.kt
grep -q 'fun listModels()' app/src/main/java/com/charlotte/companion/remote/AiGatewayClient.kt
grep -q 'chooseAvailableModel' app/src/main/java/com/charlotte/companion/remote/AiGatewayClient.kt
grep -q 'models?pageSize=100' app/src/main/java/com/charlotte/companion/remote/AiGatewayClient.kt

echo "PRECHECK=PASS"
