package com.charlotte.companion.remote

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class AiGatewayClient(private val apiKey: String) {

    data class ApiFailure(
        val httpCode: Int,
        val status: String,
        val message: String
    )

    fun test(model: String): String {
        return request(
            model = model,
            prompt = "Reply with exactly: CHARLOTTE_OK",
            jpegBase64 = null,
            maxOutputTokens = 32,
            jsonOutput = false
        )
    }

    fun respond(
        model: String,
        prompt: String,
        jpegBase64: String,
        maxOutputTokens: Int = 500
    ): String {
        return request(
            model = model,
            prompt = prompt,
            jpegBase64 = jpegBase64,
            maxOutputTokens = maxOutputTokens,
            jsonOutput = true
        )
    }

    private fun request(
        model: String,
        prompt: String,
        jpegBase64: String?,
        maxOutputTokens: Int,
        jsonOutput: Boolean
    ): String {
        val encodedModel = URLEncoder.encode(model, "UTF-8")
        val connection = URL(
            "https://generativelanguage.googleapis.com/v1beta/models/$encodedModel:generateContent"
        ).openConnection() as HttpURLConnection

        connection.requestMethod = "POST"
        connection.connectTimeout = 15000
        connection.readTimeout = 45000
        connection.doOutput = true
        connection.setRequestProperty("x-goog-api-key", apiKey)
        connection.setRequestProperty("Content-Type", "application/json")
        connection.setRequestProperty("Accept", "application/json")

        val parts = JSONArray().put(JSONObject().put("text", prompt))
        if (!jpegBase64.isNullOrBlank()) {
            parts.put(
                JSONObject().put(
                    "inline_data",
                    JSONObject()
                        .put("mime_type", "image/jpeg")
                        .put("data", jpegBase64)
                )
            )
        }

        val generationConfig = JSONObject()
            .put("maxOutputTokens", maxOutputTokens)
            .put("temperature", 0.3)

        if (jsonOutput) {
            generationConfig.put("responseMimeType", "application/json")
        }

        val body = JSONObject()
            .put(
                "contents",
                JSONArray().put(
                    JSONObject()
                        .put("role", "user")
                        .put("parts", parts)
                )
            )
            .put("generationConfig", generationConfig)

        connection.outputStream.use {
            it.write(body.toString().toByteArray(Charsets.UTF_8))
        }

        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
        connection.disconnect()

        if (code !in 200..299) {
            val error = parseGoogleError(code, raw)
            throw IllegalStateException(
                "Gemini HTTP ${error.httpCode} ${error.status}: ${error.message}"
            )
        }

        val root = JSONObject(raw)
        val candidates = root.optJSONArray("candidates") ?: JSONArray()
        if (candidates.length() == 0) {
            val block = root.optJSONObject("promptFeedback")
                ?.optString("blockReason", "")
                .orEmpty()
            if (block.isNotBlank()) {
                throw IllegalStateException("Gemini blocked: $block")
            }
            throw IllegalStateException("Gemini 沒有回傳候選內容")
        }

        val content = candidates.optJSONObject(0)?.optJSONObject("content")
            ?: throw IllegalStateException("Gemini 回覆缺少 content")

        val outParts = content.optJSONArray("parts") ?: JSONArray()
        val text = buildString {
            for (i in 0 until outParts.length()) {
                val t = outParts.optJSONObject(i)?.optString("text", "").orEmpty()
                if (t.isNotBlank()) append(t)
            }
        }.trim()

        if (text.isBlank()) {
            throw IllegalStateException("Gemini 回覆沒有文字內容")
        }

        return text
    }

    private fun parseGoogleError(code: Int, raw: String): ApiFailure {
        return runCatching {
            val root = JSONObject(raw)
            val e = root.optJSONObject("error")
            ApiFailure(
                httpCode = code,
                status = e?.optString("status", "")?.ifBlank { "ERROR" } ?: "ERROR",
                message = e?.optString("message", "")?.ifBlank { raw.take(300) }
                    ?: raw.take(300)
            )
        }.getOrElse {
            ApiFailure(code, "ERROR", raw.take(300).ifBlank { "未知錯誤" })
        }
    }
}
