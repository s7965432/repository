package com.charlotte.companion.prefs

import android.content.Context
import com.charlotte.companion.model.AgentMode

object CharlottePrefs {
    private const val NAME = "charlotte_prefs"
    private const val KEY_API = "gemini_api_key"
    private const val KEY_MODE = "agent_mode"
    private const val KEY_WATCH_MODEL = "watch_model"
    private const val KEY_DEEP_MODEL = "deep_model"

    const val DEFAULT_WATCH_MODEL = "gemini-2.5-flash-lite"
    const val DEFAULT_DEEP_MODEL = "gemini-2.5-flash"

    fun setApiKey(context: Context, key: String) {
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_API, key.trim()).apply()
    }

    fun getApiKey(context: Context): String =
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .getString(KEY_API, "") ?: ""

    fun setMode(context: Context, mode: AgentMode) {
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_MODE, mode.name).apply()
    }

    fun getMode(context: Context): AgentMode {
        val raw = context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .getString(KEY_MODE, AgentMode.ASSIST.name)
        return runCatching { AgentMode.valueOf(raw ?: AgentMode.ASSIST.name) }
            .getOrDefault(AgentMode.ASSIST)
    }

    fun setModels(context: Context, watchModel: String, deepModel: String) {
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit()
            .putString(KEY_WATCH_MODEL, watchModel.ifBlank { DEFAULT_WATCH_MODEL })
            .putString(KEY_DEEP_MODEL, deepModel.ifBlank { DEFAULT_DEEP_MODEL })
            .apply()
    }

    fun getWatchModel(context: Context): String =
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .getString(KEY_WATCH_MODEL, DEFAULT_WATCH_MODEL) ?: DEFAULT_WATCH_MODEL

    fun getDeepModel(context: Context): String =
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .getString(KEY_DEEP_MODEL, DEFAULT_DEEP_MODEL) ?: DEFAULT_DEEP_MODEL
}
