#!/usr/bin/env bash
set -euo pipefail

test -f gradle.properties
grep -q "android.useAndroidX=true" gradle.properties

test -f app/src/main/AndroidManifest.xml
test -f app/src/main/java/com/charlotte/companion/overlay/OverlayBubbleService.kt
test -f app/src/main/java/com/charlotte/companion/overlay/ConversationOverlayService.kt

grep -q 'applicationId = "com.charlotte.companion"' app/build.gradle.kts
grep -q 'versionName = "0.9.0-alpha7"' app/build.gradle.kts
grep -q 'text = "×"' app/src/main/java/com/charlotte/companion/overlay/OverlayBubbleService.kt
grep -q '關閉懸浮夏洛特' app/src/main/java/com/charlotte/companion/overlay/ConversationOverlayService.kt

echo "PRECHECK=PASS"
