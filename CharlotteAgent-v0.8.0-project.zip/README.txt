Charlotte AI Agent v0.8.0

Closed loop:
MediaProjection continuous capture -> JPEG sample -> Vercel AI Gateway vision model -> JSON decision -> Accessibility gesture -> next frame.

Default model: google/gemini-2.5-flash-lite
Endpoint: https://ai-gateway.vercel.sh/v1/responses

Modes:
- Observe: AI describes/decides but no action is executed.
- Assist: AI suggests action but no action is executed.
- Auto: AI action is executed through AccessibilityService.

Supported actions:
none, tap, swipe, long_press, multi_swipe (up to 3 simultaneous strokes), back, home.

The app requires a Vercel AI Gateway API key entered in the UI. The key is stored in the app's private SharedPreferences for this test build.
