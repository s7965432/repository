package com.charlotte.agent.v080;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int CAPTURE_REQUEST = 5001;
    private static final String PREFS = "charlotte_agent";
    private MediaProjectionManager projectionManager;
    private EditText keyInput;
    private EditText modelInput;
    private EditText goalInput;
    private Spinner modeSpinner;
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        projectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7001);
        }

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(40, 36, 40, 36);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        scroll.addView(root, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = new TextView(this);
        title.setText("夏洛特 AI 代理遊戲器\nv0.8.0");
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);
        title.setTextColor(Color.WHITE);
        root.addView(title);

        status = new TextView(this);
        status.setText("\n閉環：持續觀看 → AI 理解 → 決策 → 手機操作\n");
        status.setTextSize(16);
        status.setGravity(Gravity.CENTER);
        status.setTextColor(Color.LTGRAY);
        root.addView(status);

        TextView keyLabel = label("Vercel AI Gateway Key");
        root.addView(keyLabel);
        keyInput = new EditText(this);
        keyInput.setHint("貼上 AI Gateway Key");
        keyInput.setSingleLine(true);
        keyInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        keyInput.setText(prefs.getString("gateway_key", ""));
        root.addView(keyInput, fullWidth());

        TextView modelLabel = label("視覺模型");
        root.addView(modelLabel);
        modelInput = new EditText(this);
        modelInput.setSingleLine(true);
        modelInput.setText(prefs.getString("model", "google/gemini-2.5-flash-lite"));
        root.addView(modelInput, fullWidth());

        TextView goalLabel = label("夏洛特目前目標");
        root.addView(goalLabel);
        goalInput = new EditText(this);
        goalInput.setMinLines(2);
        goalInput.setMaxLines(4);
        goalInput.setText(prefs.getString("goal", "理解目前畫面並合理行動。遊戲中以完成本局、生存與擊敗敵人為目標；非遊戲畫面避免高風險操作。"));
        root.addView(goalInput, fullWidth());

        TextView modeLabel = label("模式");
        root.addView(modeLabel);
        modeSpinner = new Spinner(this);
        String[] modes = new String[]{"觀察", "輔助", "自動"};
        modeSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, modes));
        modeSpinner.setSelection(Math.max(0, Math.min(2, prefs.getInt("mode_index", 0))));
        root.addView(modeSpinner, fullWidth());

        Button save = button("儲存 AI 設定");
        save.setOnClickListener(v -> {
            saveSettings();
            Toast.makeText(this, "AI 設定已儲存", Toast.LENGTH_SHORT).show();
        });
        root.addView(save, fullWidth());

        Button accessibility = button("開啟操作權限");
        accessibility.setOnClickListener(v -> {
            saveSettings();
            try {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            } catch (Throwable t) {
                Toast.makeText(this, "無法開啟操作權限", Toast.LENGTH_LONG).show();
            }
        });
        root.addView(accessibility, fullWidth());

        Button watch = button("啟動 AI 代理");
        watch.setOnClickListener(v -> {
            saveSettings();
            if (keyInput.getText().toString().trim().isEmpty()) {
                Toast.makeText(this, "先填入 Vercel AI Gateway Key", Toast.LENGTH_LONG).show();
                return;
            }
            try {
                if (projectionManager == null) {
                    Toast.makeText(this, "系統不支援畫面擷取", Toast.LENGTH_LONG).show();
                    return;
                }
                startActivityForResult(projectionManager.createScreenCaptureIntent(), CAPTURE_REQUEST);
            } catch (Throwable t) {
                Toast.makeText(this, "無法開啟畫面觀看：" + t.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
            }
        });
        root.addView(watch, fullWidth());

        Button stop = button("停止 AI 代理");
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, WatchService.class));
            AgentAccessibilityService.updateOverlay("夏洛特：已停止");
            Toast.makeText(this, "已停止 AI 代理", Toast.LENGTH_SHORT).show();
        });
        root.addView(stop, fullWidth());

        setContentView(scroll);
    }

    private void saveSettings() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putString("gateway_key", keyInput.getText().toString().trim())
            .putString("model", modelInput.getText().toString().trim())
            .putString("goal", goalInput.getText().toString().trim())
            .putInt("mode_index", modeSpinner.getSelectedItemPosition())
            .apply();
    }

    private TextView label(String text) {
        TextView v = new TextView(this);
        v.setText("\n" + text);
        v.setTextSize(15);
        v.setTextColor(Color.LTGRAY);
        return v;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        return b;
    }

    private LinearLayout.LayoutParams fullWidth() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, 8, 0, 8);
        return p;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != CAPTURE_REQUEST) return;
        if (resultCode != RESULT_OK || data == null) {
            Toast.makeText(this, "已取消畫面觀看", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            Intent service = new Intent(this, WatchService.class);
            service.putExtra("resultCode", resultCode);
            service.putExtra("data", data);
            startForegroundService(service);
            status.setText("\nAI 代理已啟動。切換到要讓夏洛特觀看的 App。\n");
            Toast.makeText(this, "夏洛特開始觀看並進入 AI 閉環", Toast.LENGTH_LONG).show();
        } catch (Throwable t) {
            Toast.makeText(this, "代理服務啟動失敗：" + t.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
        }
    }
}
