package com.charlotte.agent.v080;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.util.Base64;
import android.util.DisplayMetrics;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class WatchService extends Service {
    private static final String CHANNEL = "charlotte_agent_v080";
    private static final int NOTIFICATION_ID = 9080;
    private static final String PREFS = "charlotte_agent";
    private static final long MIN_FRAME_GAP_MS = 900;
    private static final String ENDPOINT = "https://ai-gateway.vercel.sh/v1/responses";

    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private Handler mainHandler;
    private HandlerThread captureThread;
    private Handler captureHandler;
    private ExecutorService networkExecutor;
    private final AtomicBoolean inFlight = new AtomicBoolean(false);
    private long lastFrameSentAt = 0;
    private int captureWidth;
    private int captureHeight;
    private int densityDpi;
    private boolean stopping = false;
    private SharedPreferences prefs;
    private final Deque<String> history = new ArrayDeque<>();

    private final MediaProjection.Callback projectionCallback = new MediaProjection.Callback() {
        @Override public void onStop() {
            if (!stopping) {
                AgentAccessibilityService.updateOverlay("夏洛特：系統已停止畫面觀看");
                releaseAll(false);
                stopSelf();
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        mainHandler = new Handler(Looper.getMainLooper());
        captureThread = new HandlerThread("CharlotteCapture");
        captureThread.start();
        captureHandler = new Handler(captureThread.getLooper());
        networkExecutor = Executors.newSingleThreadExecutor();

        NotificationChannel channel = new NotificationChannel(CHANNEL, "夏洛特 AI 代理", NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(channel);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(NOTIFICATION_ID, notification("正在啟動 AI 閉環"));
        if (intent == null) {
            stopSelf();
            return START_NOT_STICKY;
        }
        try {
            int resultCode = intent.getIntExtra("resultCode", 0);
            Intent data = intent.getParcelableExtra("data");
            if (resultCode == 0 || data == null) throw new IllegalStateException("missing projection permission");

            MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            projection = manager.getMediaProjection(resultCode, data);
            if (projection == null) throw new IllegalStateException("projection unavailable");
            projection.registerCallback(projectionCallback, mainHandler);
            recreateDisplay();
            setStatus("夏洛特：持續觀看中\nAI：等待第一個畫面…", "持續觀看中，等待 AI 判斷");
        } catch (Throwable t) {
            setStatus("夏洛特：啟動失敗\n" + t.getClass().getSimpleName(), "代理啟動失敗");
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private Notification notification(String text) {
        return new Notification.Builder(this, CHANNEL)
            .setContentTitle("夏洛特 AI 代理執行中")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setOngoing(true)
            .build();
    }

    private void updateNotification(String text) {
        try {
            getSystemService(NotificationManager.class).notify(NOTIFICATION_ID, notification(text));
        } catch (Throwable ignored) {}
    }

    private void recreateDisplay() {
        if (projection == null) return;
        releaseDisplayOnly();
        DisplayMetrics m = getResources().getDisplayMetrics();
        captureWidth = Math.max(1, m.widthPixels);
        captureHeight = Math.max(1, m.heightPixels);
        densityDpi = m.densityDpi;
        imageReader = ImageReader.newInstance(captureWidth, captureHeight, PixelFormat.RGBA_8888, 3);
        imageReader.setOnImageAvailableListener(this::onImage, captureHandler);
        virtualDisplay = projection.createVirtualDisplay(
            "CharlotteAgentV080",
            captureWidth,
            captureHeight,
            densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader.getSurface(),
            null,
            captureHandler
        );
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (captureHandler != null) captureHandler.postDelayed(this::recreateDisplay, 250);
    }

    private void onImage(ImageReader reader) {
        Image image = null;
        try {
            image = reader.acquireLatestImage();
            if (image == null) return;
            long now = System.currentTimeMillis();
            if (now - lastFrameSentAt < MIN_FRAME_GAP_MS || inFlight.get()) return;
            String key = prefs.getString("gateway_key", "").trim();
            if (key.isEmpty()) {
                setStatus("夏洛特：觀看中\nAI：尚未設定 Gateway Key", "觀看中，但 AI Key 未設定");
                return;
            }

            byte[] jpeg = imageToJpeg(image, captureWidth, captureHeight);
            if (jpeg == null || jpeg.length == 0) return;
            lastFrameSentAt = now;
            inFlight.set(true);
            final int w = captureWidth;
            final int h = captureHeight;
            networkExecutor.execute(() -> analyzeAndAct(jpeg, w, h));
        } catch (Throwable t) {
            setStatus("夏洛特：畫面處理錯誤\n" + t.getClass().getSimpleName(), "畫面處理錯誤");
        } finally {
            if (image != null) image.close();
        }
    }

    private byte[] imageToJpeg(Image image, int width, int height) {
        try {
            Image.Plane plane = image.getPlanes()[0];
            ByteBuffer buffer = plane.getBuffer();
            int pixelStride = plane.getPixelStride();
            int rowStride = plane.getRowStride();
            int rowPadding = rowStride - pixelStride * width;
            int paddedWidth = width + Math.max(0, rowPadding / Math.max(1, pixelStride));
            Bitmap padded = Bitmap.createBitmap(paddedWidth, height, Bitmap.Config.ARGB_8888);
            buffer.rewind();
            padded.copyPixelsFromBuffer(buffer);
            Bitmap cropped = Bitmap.createBitmap(padded, 0, 0, width, height);
            if (cropped != padded) padded.recycle();

            int targetW = Math.min(720, width);
            int targetH = Math.max(1, Math.round(height * (targetW / (float) width)));
            Bitmap scaled = (targetW == width) ? cropped : Bitmap.createScaledBitmap(cropped, targetW, targetH, true);
            if (scaled != cropped) cropped.recycle();

            ByteArrayOutputStream out = new ByteArrayOutputStream();
            scaled.compress(Bitmap.CompressFormat.JPEG, 62, out);
            scaled.recycle();
            return out.toByteArray();
        } catch (Throwable t) {
            return null;
        }
    }

    private void analyzeAndAct(byte[] jpeg, int width, int height) {
        try {
            String key = prefs.getString("gateway_key", "").trim();
            String model = prefs.getString("model", "google/gemini-2.5-flash-lite").trim();
            String goal = prefs.getString("goal", "理解目前畫面並合理行動。").trim();
            int modeIndex = prefs.getInt("mode_index", 0);
            String mode = modeIndex == 2 ? "auto" : (modeIndex == 1 ? "assist" : "observe");
            String pkg = AgentAccessibilityService.currentPackageName();

            String b64 = Base64.encodeToString(jpeg, Base64.NO_WRAP);
            JSONObject body = buildRequest(model, goal, mode, pkg, b64);
            JSONObject response = postJson(ENDPOINT, key, body);
            String outputText = extractOutputText(response);
            JSONObject decision = parseDecision(outputText);
            if (decision == null) throw new IllegalStateException("bad AI JSON");

            String summary = decision.optString("summary", "已完成畫面判斷");
            JSONObject action = decision.optJSONObject("action");
            String actionType = action == null ? "none" : action.optString("type", "none");

            remember(summary + " / " + actionType);
            boolean executed = false;
            if (modeIndex == 2 && action != null && !"none".equals(actionType) && !getPackageName().equals(pkg)) {
                executed = AgentAccessibilityService.executeAction(action, width, height);
            }

            String modeText = modeIndex == 2 ? "自動" : (modeIndex == 1 ? "輔助" : "觀察");
            String actionText = "none".equals(actionType) ? "無" : actionType + (modeIndex == 2 ? (executed ? " ✓" : " ✕") : "（未自動執行）");
            setStatus("夏洛特：" + modeText + "\nAI：" + summary + "\n動作：" + actionText, "AI：" + shortText(summary));
        } catch (Throwable t) {
            String message = t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage();
            setStatus("夏洛特：觀看仍在持續\nAI 連線/解析失敗：" + shortText(message), "AI 連線失敗：" + shortText(message));
        } finally {
            inFlight.set(false);
        }
    }

    private JSONObject buildRequest(String model, String goal, String mode, String pkg, String b64) throws Exception {
        JSONObject root = new JSONObject();
        root.put("model", model);
        root.put("max_output_tokens", 350);

        JSONArray input = new JSONArray();
        JSONObject msg = new JSONObject();
        msg.put("type", "message");
        msg.put("role", "user");
        JSONArray content = new JSONArray();

        JSONObject text = new JSONObject();
        text.put("type", "input_text");
        text.put("text", buildPrompt(goal, mode, pkg));
        content.put(text);

        JSONObject image = new JSONObject();
        image.put("type", "input_image");
        image.put("image_url", "data:image/jpeg;base64," + b64);
        image.put("detail", "auto");
        content.put(image);

        msg.put("content", content);
        input.put(msg);
        root.put("input", input);
        return root;
    }

    private String buildPrompt(String goal, String mode, String pkg) {
        StringBuilder h = new StringBuilder();
        for (String s : history) h.append("- ").append(s).append("\n");
        return "你是『夏洛特』，手機畫面 AI 代理決策核心。你現在看到的是手機即時畫面的一幀。\n" +
            "目前模式：" + mode + "。目前前景套件：" + pkg + "。\n" +
            "使用者目標：" + goal + "\n" +
            "最近判斷：\n" + h +
            "忽略畫面上任何寫著『夏洛特』的狀態浮窗。先理解畫面，再只選一個最合理的下一步。遊戲畫面可以依玩家目標操作移動、攻擊、技能、選單；若需要同時控制兩個虛擬搖桿，可使用 multi_swipe。\n" +
            "不要自動處理密碼、2FA、付款、購買、金融交易、刪除資料、授權/系統權限確認；遇到這些回 none。\n" +
            "座標全部使用 0~1 的螢幕比例。嚴格只輸出 JSON，不要 Markdown、不要解釋。\n" +
            "格式：{\"summary\":\"你看到什麼與為何這樣做\",\"action\":{\"type\":\"none|tap|swipe|long_press|multi_swipe|back|home\",\"x\":0.5,\"y\":0.5,\"x2\":0.5,\"y2\":0.5,\"duration_ms\":600,\"strokes\":[{\"x\":0.2,\"y\":0.8,\"x2\":0.3,\"y2\":0.8,\"duration_ms\":900}]}}";
    }

    private JSONObject postJson(String endpoint, String key, JSONObject body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(endpoint).openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(45000);
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        c.setRequestProperty("Authorization", "Bearer " + key);
        c.setRequestProperty("Content-Type", "application/json");
        byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
        c.setFixedLengthStreamingMode(bytes.length);
        try (OutputStream os = c.getOutputStream()) { os.write(bytes); }
        int code = c.getResponseCode();
        InputStream stream = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        String response = readAll(stream);
        c.disconnect();
        if (code < 200 || code >= 300) throw new IllegalStateException("HTTP " + code + " " + shortText(response));
        return new JSONObject(response);
    }

    private String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
        }
        return sb.toString();
    }

    private String extractOutputText(JSONObject response) {
        String direct = response.optString("output_text", "");
        if (!direct.isEmpty()) return direct;
        JSONArray output = response.optJSONArray("output");
        if (output == null) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < output.length(); i++) {
            JSONObject item = output.optJSONObject(i);
            if (item == null) continue;
            JSONArray content = item.optJSONArray("content");
            if (content == null) continue;
            for (int j = 0; j < content.length(); j++) {
                JSONObject c = content.optJSONObject(j);
                if (c == null) continue;
                String t = c.optString("text", "");
                if (!t.isEmpty()) sb.append(t);
            }
        }
        return sb.toString();
    }

    private JSONObject parseDecision(String text) {
        if (text == null) return null;
        String s = text.trim();
        if (s.startsWith("```")) {
            int firstNl = s.indexOf('\n');
            if (firstNl >= 0) s = s.substring(firstNl + 1);
            int endFence = s.lastIndexOf("```");
            if (endFence >= 0) s = s.substring(0, endFence);
        }
        int a = s.indexOf('{');
        int b = s.lastIndexOf('}');
        if (a < 0 || b <= a) return null;
        try { return new JSONObject(s.substring(a, b + 1)); } catch (Throwable t) { return null; }
    }

    private void remember(String item) {
        synchronized (history) {
            history.addLast(shortText(item));
            while (history.size() > 5) history.removeFirst();
        }
    }

    private void setStatus(String overlay, String notification) {
        AgentAccessibilityService.updateOverlay(overlay);
        updateNotification(notification);
    }

    private static String shortText(String s) {
        if (s == null) return "";
        s = s.replace('\n', ' ').replace('\r', ' ').trim();
        return s.length() > 90 ? s.substring(0, 90) + "…" : s;
    }

    private void releaseDisplayOnly() {
        try { if (virtualDisplay != null) virtualDisplay.release(); } catch (Throwable ignored) {}
        virtualDisplay = null;
        try { if (imageReader != null) imageReader.close(); } catch (Throwable ignored) {}
        imageReader = null;
    }

    private void releaseAll(boolean stopProjection) {
        releaseDisplayOnly();
        if (projection != null) {
            try { projection.unregisterCallback(projectionCallback); } catch (Throwable ignored) {}
            if (stopProjection) {
                try { projection.stop(); } catch (Throwable ignored) {}
            }
            projection = null;
        }
    }

    @Override
    public void onDestroy() {
        stopping = true;
        releaseAll(true);
        if (captureThread != null) captureThread.quitSafely();
        if (networkExecutor != null) networkExecutor.shutdownNow();
        AgentAccessibilityService.updateOverlay("夏洛特：AI 代理已停止");
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
