package com.charlotte.agent.v080;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;

public class AgentAccessibilityService extends AccessibilityService {
    private static AgentAccessibilityService instance;
    private String currentPackage = "";
    private WindowManager windowManager;
    private TextView overlay;
    private boolean compact = false;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        createOverlay();
        updateOverlay("夏洛特：操作權限已開啟");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event != null && event.getPackageName() != null) {
            currentPackage = event.getPackageName().toString();
        }
    }

    @Override
    public void onInterrupt() {}

    @Override
    public void onDestroy() {
        removeOverlay();
        if (instance == this) instance = null;
        super.onDestroy();
    }

    public static AgentAccessibilityService getInstance() { return instance; }

    public String getCurrentPackage() { return currentPackage; }

    public static String currentPackageName() {
        AgentAccessibilityService s = instance;
        return s == null ? "unknown" : s.currentPackage;
    }

    public static void updateOverlay(String text) {
        AgentAccessibilityService s = instance;
        if (s == null || s.overlay == null) return;
        s.overlay.post(() -> {
            if (s.overlay == null) return;
            if (s.compact) {
                String one = text == null ? "夏洛特" : text.replace('\n', ' ');
                if (one.length() > 34) one = one.substring(0, 34) + "…";
                s.overlay.setText(one);
            } else {
                s.overlay.setText(text == null ? "夏洛特" : text);
            }
        });
    }

    private void createOverlay() {
        try {
            windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
            overlay = new TextView(this);
            overlay.setTextColor(Color.WHITE);
            overlay.setTextSize(13);
            overlay.setPadding(18, 10, 18, 10);
            overlay.setMaxLines(5);
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(0xB5222222);
            bg.setCornerRadius(18f);
            overlay.setBackground(bg);
            overlay.setOnClickListener(v -> {
                compact = !compact;
                updateOverlay(compact ? "夏洛特：AI 代理中（點我展開）" : "夏洛特：AI 代理中\n等待下一個畫面判斷…");
            });

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
                    WindowManager.LayoutParams.FLAG_SECURE,
                PixelFormat.TRANSLUCENT
            );
            lp.gravity = Gravity.TOP | Gravity.START;
            lp.x = 16;
            lp.y = 72;
            windowManager.addView(overlay, lp);
        } catch (Throwable ignored) {}
    }

    private void removeOverlay() {
        try {
            if (windowManager != null && overlay != null) windowManager.removeView(overlay);
        } catch (Throwable ignored) {}
        overlay = null;
    }

    public static boolean executeAction(JSONObject action, int width, int height) {
        AgentAccessibilityService s = instance;
        if (s == null || action == null) return false;
        String type = action.optString("type", "none");
        switch (type) {
            case "tap":
                return s.tap(nx(action.optDouble("x", 0.5), width), ny(action.optDouble("y", 0.5), height));
            case "swipe":
                return s.swipe(
                    nx(action.optDouble("x", 0.5), width),
                    ny(action.optDouble("y", 0.5), height),
                    nx(action.optDouble("x2", 0.5), width),
                    ny(action.optDouble("y2", 0.5), height),
                    clampDuration(action.optLong("duration_ms", 450))
                );
            case "long_press":
                return s.longPress(
                    nx(action.optDouble("x", 0.5), width),
                    ny(action.optDouble("y", 0.5), height),
                    clampDuration(action.optLong("duration_ms", 800))
                );
            case "multi_swipe":
                return s.multiSwipe(action.optJSONArray("strokes"), width, height);
            case "back":
                return s.performGlobalAction(GLOBAL_ACTION_BACK);
            case "home":
                return s.performGlobalAction(GLOBAL_ACTION_HOME);
            default:
                return true;
        }
    }

    private static float nx(double v, int w) { return (float)(Math.max(0, Math.min(1, v)) * Math.max(1, w - 1)); }
    private static float ny(double v, int h) { return (float)(Math.max(0, Math.min(1, v)) * Math.max(1, h - 1)); }
    private static long clampDuration(long d) { return Math.max(50, Math.min(2500, d)); }

    public boolean tap(float x, float y) {
        Path p = new Path();
        p.moveTo(x, y);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(p, 0, 70);
        return dispatchGesture(new GestureDescription.Builder().addStroke(stroke).build(), null, null);
    }

    public boolean longPress(float x, float y, long duration) {
        Path p = new Path();
        p.moveTo(x, y);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(p, 0, duration);
        return dispatchGesture(new GestureDescription.Builder().addStroke(stroke).build(), null, null);
    }

    public boolean swipe(float sx, float sy, float ex, float ey, long duration) {
        Path p = new Path();
        p.moveTo(sx, sy);
        p.lineTo(ex, ey);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(p, 0, duration);
        return dispatchGesture(new GestureDescription.Builder().addStroke(stroke).build(), null, null);
    }

    private boolean multiSwipe(JSONArray strokes, int width, int height) {
        if (strokes == null || strokes.length() == 0) return false;
        GestureDescription.Builder builder = new GestureDescription.Builder();
        int limit = Math.min(strokes.length(), 3);
        for (int i = 0; i < limit; i++) {
            JSONObject st = strokes.optJSONObject(i);
            if (st == null) continue;
            Path p = new Path();
            p.moveTo(nx(st.optDouble("x", 0.5), width), ny(st.optDouble("y", 0.5), height));
            p.lineTo(nx(st.optDouble("x2", st.optDouble("x", 0.5)), width), ny(st.optDouble("y2", st.optDouble("y", 0.5)), height));
            long duration = clampDuration(st.optLong("duration_ms", 900));
            builder.addStroke(new GestureDescription.StrokeDescription(p, 0, duration));
        }
        try {
            return dispatchGesture(builder.build(), null, null);
        } catch (Throwable t) {
            return false;
        }
    }
}
