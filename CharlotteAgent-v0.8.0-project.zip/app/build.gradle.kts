plugins {
    id("com.android.application")
}

android {
    namespace = "com.charlotte.agent.v080"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.charlotte.agent.v080"
        minSdk = 26
        targetSdk = 35
        versionCode = 10
        versionName = "0.8.0"
    }
}
