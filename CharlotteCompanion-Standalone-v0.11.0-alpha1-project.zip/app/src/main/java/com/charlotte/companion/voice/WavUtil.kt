package com.charlotte.companion.voice

import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.roundToInt

object WavUtil {

    data class Wave(
        val samples: FloatArray,
        val sampleRate: Int
    )

    fun pcm16ToWav(
        pcm: File,
        wav: File,
        sampleRate: Int,
        channels: Int = 1
    ) {
        val dataSize = pcm.length()
        val byteRate = sampleRate * channels * 2
        val blockAlign = channels * 2

        RandomAccessFile(wav, "rw").use { out ->
            out.setLength(0)
            out.writeBytes("RIFF")
            writeLe32(out, (36L + dataSize).toInt())
            out.writeBytes("WAVE")
            out.writeBytes("fmt ")
            writeLe32(out, 16)
            writeLe16(out, 1) // PCM
            writeLe16(out, channels)
            writeLe32(out, sampleRate)
            writeLe32(out, byteRate)
            writeLe16(out, blockAlign)
            writeLe16(out, 16)
            out.writeBytes("data")
            writeLe32(out, dataSize.toInt())

            pcm.inputStream().use { input ->
                input.copyTo(object : java.io.OutputStream() {
                    override fun write(b: Int) = out.write(b)
                    override fun write(b: ByteArray, off: Int, len: Int) =
                        out.write(b, off, len)
                })
            }
        }
    }

    fun readPcm16Wav(file: File): Wave {
        val bytes = file.readBytes()
        require(bytes.size >= 44) { "WAV 太短" }
        require(String(bytes, 0, 4, Charsets.US_ASCII) == "RIFF") { "不是 RIFF WAV" }
        require(String(bytes, 8, 4, Charsets.US_ASCII) == "WAVE") { "不是 WAVE" }

        var offset = 12
        var sampleRate = 16000
        var channels = 1
        var bits = 16
        var dataOffset = -1
        var dataSize = 0

        while (offset + 8 <= bytes.size) {
            val id = String(bytes, offset, 4, Charsets.US_ASCII)
            val size = le32(bytes, offset + 4)
            val body = offset + 8

            if (id == "fmt " && body + size <= bytes.size) {
                channels = le16(bytes, body + 2)
                sampleRate = le32(bytes, body + 4)
                bits = le16(bytes, body + 14)
            } else if (id == "data") {
                dataOffset = body
                dataSize = size.coerceAtMost(bytes.size - body)
                break
            }

            offset = body + size + (size and 1)
        }

        require(dataOffset >= 0) { "WAV 沒有 data" }
        require(bits == 16) { "目前只支援 PCM16 WAV" }

        val frameBytes = channels * 2
        val frames = dataSize / frameBytes
        val out = FloatArray(frames)
        var p = dataOffset

        for (i in 0 until frames) {
            var sum = 0
            for (ch in 0 until channels) {
                val lo = bytes[p++].toInt() and 0xff
                val hi = bytes[p++].toInt()
                val v = (hi shl 8) or lo
                sum += v.toShort().toInt()
            }
            out[i] = (sum / channels.toFloat()) / 32768f
        }

        return Wave(out, sampleRate)
    }

    fun floatToPcm16(samples: FloatArray): ShortArray =
        ShortArray(samples.size) { i ->
            (samples[i].coerceIn(-1f, 1f) * 32767f)
                .roundToInt().coerceIn(-32768, 32767).toShort()
        }

    private fun writeLe16(out: RandomAccessFile, value: Int) {
        out.write(value and 0xff)
        out.write((value ushr 8) and 0xff)
    }

    private fun writeLe32(out: RandomAccessFile, value: Int) {
        out.write(value and 0xff)
        out.write((value ushr 8) and 0xff)
        out.write((value ushr 16) and 0xff)
        out.write((value ushr 24) and 0xff)
    }

    private fun le16(b: ByteArray, o: Int): Int =
        (b[o].toInt() and 0xff) or ((b[o + 1].toInt() and 0xff) shl 8)

    private fun le32(b: ByteArray, o: Int): Int =
        (b[o].toInt() and 0xff) or
            ((b[o + 1].toInt() and 0xff) shl 8) or
            ((b[o + 2].toInt() and 0xff) shl 16) or
            ((b[o + 3].toInt() and 0xff) shl 24)
}
