package com.charlotte.companion.voice

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import com.k2fsa.sherpa.onnx.GenerationConfig
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsZipVoiceModelConfig
import java.util.concurrent.atomic.AtomicBoolean

class ZipVoiceCloneEngine(
    private val context: Context
) {
    private val cancelled = AtomicBoolean(false)

    fun isReady(): Boolean =
        ZipVoiceModelManager.isReady(context) &&
            VoiceCloneStore.hasReference(context)

    fun speak(
        text: String,
        onDone: (() -> Unit)? = null
    ) {
        cancelled.set(false)

        val modelDir = ZipVoiceModelManager.modelDir(context)
        val wav = VoiceCloneStore.referenceWav(context)
        val refText = VoiceCloneStore.referenceText(context)

        require(ZipVoiceModelManager.isReady(context)) {
            "音色模型尚未下載"
        }
        require(wav.isFile && refText.isNotBlank()) {
            "還沒有可用的角色原聲與台詞"
        }

        val zip = OfflineTtsZipVoiceModelConfig(
            tokens = java.io.File(modelDir, "tokens.txt").absolutePath,
            encoder = java.io.File(modelDir, "encoder.int8.onnx").absolutePath,
            decoder = java.io.File(modelDir, "decoder.int8.onnx").absolutePath,
            vocoder = ZipVoiceModelManager.vocoder(context).absolutePath,
            dataDir = java.io.File(modelDir, "espeak-ng-data").absolutePath,
            lexicon = java.io.File(modelDir, "lexicon.txt").absolutePath
        )

        val tts = OfflineTts(
            config = OfflineTtsConfig(
                model = OfflineTtsModelConfig(
                    zipvoice = zip,
                    numThreads = 2,
                    debug = false,
                    provider = "cpu"
                ),
                maxNumSentences = 1
            )
        )

        var completed = false

        try {
            val reference = WavUtil.readPcm16Wav(wav)

            val generation = GenerationConfig(
                speed = 1.0f,
                referenceAudio = reference.samples,
                referenceSampleRate = reference.sampleRate,
                referenceText = refText,
                numSteps = 4,
                extra = mapOf("min_char_in_sentence" to "10")
            )

            val generated = tts.generateWithConfig(text, generation)
            if (cancelled.get()) return

            play(
                generated.samples,
                generated.sampleRate
            )

            completed = !cancelled.get()
        } finally {
            tts.release()
            if (completed) onDone?.invoke()
        }
    }

    fun stop() {
        cancelled.set(true)
    }

    private fun play(
        samples: FloatArray,
        sampleRate: Int
    ) {
        if (samples.isEmpty()) return

        val pcm = WavUtil.floatToPcm16(samples)
        val minBuffer = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(4096)

        val track = AudioTrack(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build(),
            AudioFormat.Builder()
                .setSampleRate(sampleRate)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build(),
            minBuffer,
            AudioTrack.MODE_STREAM,
            AudioManager.AUDIO_SESSION_ID_GENERATE
        )

        try {
            track.play()
            var offset = 0
            while (offset < pcm.size && !cancelled.get()) {
                val n = track.write(
                    pcm,
                    offset,
                    pcm.size - offset,
                    AudioTrack.WRITE_BLOCKING
                )
                if (n <= 0) break
                offset += n
            }
        } finally {
            runCatching { track.stop() }
            track.release()
        }
    }
}
