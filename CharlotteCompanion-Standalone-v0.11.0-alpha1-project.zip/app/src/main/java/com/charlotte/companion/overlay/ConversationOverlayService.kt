package com.charlotte.companion.overlay

import android.Manifest
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.speech.*
import android.view.Gravity
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.core.content.ContextCompat
import com.charlotte.companion.agent.CharlotteAgentLoop
import com.charlotte.companion.lm.CharlotteLocalLanguageModel
import com.charlotte.companion.lm.CharlotteLocalModelManager
import com.charlotte.companion.model.*
import com.charlotte.companion.prefs.CharlottePrefs
import com.charlotte.companion.remote.AiGatewayClient
import com.charlotte.companion.state.CharlotteStateStore
import com.charlotte.companion.voice.*
import com.charlotte.companion.watch.ProjectionPermissionActivity
import com.charlotte.companion.watch.ScreenWatchService
import kotlinx.coroutines.*

class ConversationOverlayService :
    Service(),
    RecognitionListener {

    private lateinit var windowManager: WindowManager
    private lateinit var scroll: ScrollView
    private lateinit var root: LinearLayout

    private lateinit var messageView: TextView
    private lateinit var statusView: TextView
    private lateinit var localLmStatus: TextView
    private lateinit var voiceStatus: TextView
    private lateinit var thermalStatus: TextView
    private lateinit var typedInput: EditText
    private lateinit var apiKeyInput: EditText
    private lateinit var referenceText: EditText

    private lateinit var micButton: Button
    private lateinit var continuousButton: Button
    private lateinit var learningButton: Button
    private lateinit var actionButton: Button

    private var recognizer: SpeechRecognizer? = null
    private lateinit var speech: SpeechOutputController

    private val scope = CoroutineScope(
        SupervisorJob() + Dispatchers.Main
    )

    private val handler = Handler(Looper.getMainLooper())
    private var lastSpokenMessage = ""
    private var isListening = false
    private var awaitingVoiceAnswer = false

    override fun onCreate() {
        super.onCreate()

        CharlotteStateStore.conversationOpen = true
        windowManager =
            getSystemService(WINDOW_SERVICE) as WindowManager

        speech = SpeechOutputController(this)

        messageView = label(
            "夏洛特：${CharlotteStateStore.thought.value.message}",
            17f
        )

        statusView = label(
            CharlotteStateStore.aiStatus.value,
            12f
        )

        localLmStatus = label(
            if (CharlotteLocalModelManager.isReady(this)) {
                "Charlotte-LM：已安裝"
            } else {
                "Charlotte-LM：尚未安裝"
            },
            12f
        )

        thermalStatus = label(
            "溫控：${CharlotteStateStore.thermalStatus.value}",
            12f
        )

        typedInput = EditText(this).apply {
            hint = "直接輸入給夏洛特"
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFFAAAAAA.toInt())
            maxLines = 3
        }

        val sendButton = button("送出") {
            val text = typedInput.text?.toString().orEmpty().trim()
            if (text.isNotBlank()) {
                typedInput.setText("")
                messageView.text = "你：$text\n\n夏洛特：我在想。"
                CharlotteAgentLoop.onUserVoice(
                    applicationContext,
                    text
                )
            }
        }

        micButton = button("🎙 說話") {
            speech.interrupt()
            startVoice()
        }

        continuousButton = button(
            if (CharlotteStateStore.continuousVoice) {
                "🔁 連續語音：開"
            } else {
                "🔁 連續語音：關"
            }
        ) {
            CharlotteStateStore.continuousVoice =
                !CharlotteStateStore.continuousVoice

            continuousButton.text =
                if (CharlotteStateStore.continuousVoice) {
                    "🔁 連續語音：開"
                } else {
                    "🔁 連續語音：關"
                }

            if (CharlotteStateStore.continuousVoice) {
                speech.interrupt()
                startVoice()
            } else {
                recognizer?.cancel()
                isListening = false
                micButton.text = "🎙 說話"
            }
        }

        addHeader("畫面與操作")

        val startWatch = button("開始保持觀看") {
            startActivity(
                Intent(
                    this,
                    ProjectionPermissionActivity::class.java
                ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }

        val stopWatch = button("停止保持觀看") {
            ContextCompat.startForegroundService(
                this,
                Intent(
                    this,
                    ScreenWatchService::class.java
                ).apply {
                    action =
                        ScreenWatchService.ACTION_STOP_WATCH
                }
            )
        }

        val accessibility = button("開啟操作權限") {
            startActivity(
                Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }

        addHeader("模式")

        val modeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        fun modeButton(
            label: String,
            mode: AgentMode
        ) = Button(this).apply {
            text = label
            setOnClickListener {
                CharlottePrefs.setMode(
                    applicationContext,
                    mode
                )
                Toast.makeText(
                    this@ConversationOverlayService,
                    "模式：$label",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        modeRow.addView(
            modeButton("觀察", AgentMode.OBSERVE),
            LinearLayout.LayoutParams(0, -2, 1f)
        )
        modeRow.addView(
            modeButton("輔助", AgentMode.ASSIST),
            LinearLayout.LayoutParams(0, -2, 1f)
        )
        modeRow.addView(
            modeButton("自動", AgentMode.AUTO),
            LinearLayout.LayoutParams(0, -2, 1f)
        )

        addHeader("夏洛特本機語言核心")

        val downloadLocalLm = button(
            "下載 Charlotte-LM（約 429 MB，一次）"
        ) {
            localLmStatus.text =
                "Charlotte-LM：準備下載…"

            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        CharlotteLocalModelManager.install(
                            applicationContext
                        ) { s ->
                            handler.post {
                                localLmStatus.text =
                                    "Charlotte-LM：$s"
                            }
                        }
                    }
                }

                result.onFailure {
                    localLmStatus.text =
                        "Charlotte-LM：失敗：${it.message?.take(160)}"
                }
            }
        }

        val testLocalLm = button("測試 Charlotte-LM") {
            localLmStatus.text =
                "Charlotte-LM：正在載入/測試…"

            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        CharlotteLocalLanguageModel.test(
                            applicationContext
                        )
                    }
                }

                result.onSuccess {
                    localLmStatus.text = "Charlotte-LM：$it"
                }.onFailure {
                    localLmStatus.text =
                        "Charlotte-LM：測試失敗：${it.message?.take(160)}"
                }
            }
        }

        learningButton = button(
            if (CharlottePrefs.isLanguageLearning(this)) {
                "語言學習：開"
            } else {
                "語言學習：關"
            }
        ) {
            val next =
                !CharlottePrefs.isLanguageLearning(
                    applicationContext
                )

            CharlottePrefs.setLanguageLearning(
                applicationContext,
                next
            )

            learningButton.text =
                if (next) "語言學習：開"
                else "語言學習：關"
        }

        addHeader("雲端視覺（可選）")

        apiKeyInput = EditText(this).apply {
            hint = "Google Gemini API Key"
            setText(
                CharlottePrefs.getApiKey(
                    applicationContext
                )
            )
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFFAAAAAA.toInt())
        }

        val saveApi = button("儲存 AI 連線") {
            CharlottePrefs.setApiKey(
                applicationContext,
                apiKeyInput.text?.toString().orEmpty()
            )
            Toast.makeText(
                this,
                "AI 連線已儲存",
                Toast.LENGTH_SHORT
            ).show()
        }

        val testApi = button("測試 AI 連線") {
            val key =
                apiKeyInput.text?.toString().orEmpty().trim()

            if (key.isBlank()) {
                statusView.text = "AI：先填 API Key"
                return@button
            }

            CharlottePrefs.setApiKey(
                applicationContext,
                key
            )
            statusView.text = "AI：正在測試…"

            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        AiGatewayClient(key).test(
                            listOf(
                                CharlottePrefs.DEFAULT_WATCH_MODEL,
                                "gemini-3.1-flash-lite",
                                "gemini-3-flash-preview"
                            )
                        )
                    }
                }

                result.onSuccess {
                    statusView.text =
                        "AI：測試成功 · ${it.chosenModel}"
                }.onFailure {
                    statusView.text =
                        "AI：${it.message?.take(180)}"
                }
            }
        }

        addHeader("真實音色複製")

        val downloadVoice = button(
            "下載音色模型（約 165 MB，一次）"
        ) {
            voiceStatus.text = "音色模型：準備下載…"

            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        ZipVoiceModelManager.install(
                            applicationContext
                        ) { s ->
                            handler.post {
                                voiceStatus.text =
                                    "音色模型：$s"
                            }
                        }
                    }
                }

                result.onFailure {
                    voiceStatus.text =
                        "音色模型：失敗：${it.message?.take(160)}"
                }
            }
        }

        voiceStatus = label(
            if (ZipVoiceModelManager.isReady(this)) {
                "音色模型：已安裝"
            } else {
                "音色模型：尚未安裝"
            },
            12f
        )

        referenceText = EditText(this).apply {
            hint = "角色參考台詞"
            setText(
                VoiceCloneStore.referenceText(
                    applicationContext
                )
            )
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFFAAAAAA.toInt())
        }

        val saveReference = button("保存參考台詞") {
            VoiceCloneStore.setReferenceText(
                applicationContext,
                referenceText.text?.toString().orEmpty()
            )
            Toast.makeText(
                this,
                "參考台詞已保存",
                Toast.LENGTH_SHORT
            ).show()
        }

        val startVoiceLearn = button(
            "開始擷取角色原聲（5～15 秒）"
        ) {
            ContextCompat.startForegroundService(
                this,
                Intent(
                    this,
                    ScreenWatchService::class.java
                ).apply {
                    action =
                        ScreenWatchService.ACTION_START_VOICE_LEARNING
                }
            )
        }

        val stopVoiceLearn = button(
            "停止並保存角色原聲"
        ) {
            ContextCompat.startForegroundService(
                this,
                Intent(
                    this,
                    ScreenWatchService::class.java
                ).apply {
                    action =
                        ScreenWatchService.ACTION_STOP_VOICE_LEARNING
                }
            )
        }

        val voiceTest = button("語音輸出測試") {
            speech.speak(
                "我在。現在會優先使用你保存的參考音色。"
            )
        }

        actionButton = button("讓夏洛特做") {
            val action =
                CharlotteStateStore.pendingAction

            when {
                action == null ||
                    action.type == ActionType.NONE -> {
                    Toast.makeText(
                        this,
                        "目前沒有待執行動作",
                        Toast.LENGTH_SHORT
                    ).show()
                }

                action.risk == RiskLevel.HIGH -> {
                    Toast.makeText(
                        this,
                        "高風險動作不直接執行",
                        Toast.LENGTH_LONG
                    ).show()
                }

                else -> {
                    val ok =
                        CharlotteAgentLoop.executePendingAction(
                            applicationContext
                        )

                    Toast.makeText(
                        this,
                        if (ok) "已執行"
                        else "操作權限尚未啟用",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

        val minimize = button("縮回夏洛特") {
            stopSelf()
        }

        val closeOverlay = button("關閉懸浮夏洛特") {
            stopService(
                Intent(
                    this,
                    OverlayBubbleService::class.java
                )
            )
            stopSelf()
        }

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(0xEE151515.toInt())

            addView(messageView)
            addView(statusView)
            addView(localLmStatus)
            addView(thermalStatus)

            addView(typedInput)
            addView(sendButton)
            addView(micButton)
            addView(continuousButton)

            addView(section("畫面與操作"))
            addView(startWatch)
            addView(stopWatch)
            addView(accessibility)

            addView(section("模式"))
            addView(modeRow)

            addView(section("夏洛特本機語言核心"))
            addView(downloadLocalLm)
            addView(testLocalLm)
            addView(learningButton)

            addView(section("雲端視覺（可選）"))
            addView(apiKeyInput)
            addView(saveApi)
            addView(testApi)

            addView(section("真實音色複製"))
            addView(downloadVoice)
            addView(voiceStatus)
            addView(referenceText)
            addView(saveReference)
            addView(startVoiceLearn)
            addView(stopVoiceLearn)
            addView(voiceTest)

            addView(actionButton)
            addView(minimize)
            addView(closeOverlay)
        }

        scroll = ScrollView(this).apply {
            addView(root)
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            (resources.displayMetrics.heightPixels * 0.88f).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM
            softInputMode =
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }

        windowManager.addView(scroll, params)

        scope.launch {
            CharlotteStateStore.aiStatus.collect {
                statusView.text = it
            }
        }

        scope.launch {
            CharlotteStateStore.localLmStatus.collect {
                localLmStatus.text = "Charlotte-LM：$it"
            }
        }

        scope.launch {
            CharlotteStateStore.thermalStatus.collect {
                thermalStatus.text = "溫控：$it"
            }
        }

        scope.launch {
            CharlotteStateStore.voiceLearningStatus.collect {
                voiceStatus.text = "聲音學習：$it"

                val saved =
                    VoiceCloneStore.referenceText(
                        applicationContext
                    )

                if (saved.isNotBlank() &&
                    referenceText.text?.toString() != saved
                ) {
                    referenceText.setText(saved)
                }
            }
        }

        scope.launch {
            CharlotteStateStore.thought.collect { thought ->
                messageView.text =
                    "夏洛特：${thought.message}"

                val action = thought.action
                actionButton.isEnabled =
                    action != null &&
                    action.type != ActionType.NONE &&
                    action.risk != RiskLevel.HIGH

                val shouldSpeak =
                    thought.speak &&
                        thought.message.isNotBlank() &&
                        thought.message != lastSpokenMessage

                if (shouldSpeak) {
                    lastSpokenMessage = thought.message
                    awaitingVoiceAnswer = false

                    speech.speak(thought.message) {
                        handler.post {
                            if (
                                CharlotteStateStore.continuousVoice
                            ) {
                                handler.postDelayed(
                                    { startVoice() },
                                    350
                                )
                            }
                        }
                    }
                } else if (
                    awaitingVoiceAnswer &&
                    CharlotteStateStore.continuousVoice
                ) {
                    awaitingVoiceAnswer = false
                    handler.postDelayed(
                        { startVoice() },
                        450
                    )
                }
            }
        }
    }

    private fun addHeader(text: String) = Unit

    private fun section(text: String): TextView =
        label(text, 16f).apply {
            setPadding(0, 16, 0, 6)
        }

    private fun label(
        textValue: String,
        size: Float
    ): TextView =
        TextView(this).apply {
            text = textValue
            textSize = size
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 0, 0, 8)
        }

    private fun button(
        textValue: String,
        action: () -> Unit
    ): Button =
        Button(this).apply {
            text = textValue
            setOnClickListener { action() }
        }

    private fun startVoice() {
        if (isListening) return

        if (
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            messageView.text =
                "夏洛特：麥克風權限還沒開。"
            return
        }

        speech.interrupt()

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            messageView.text =
                "夏洛特：手機沒有可用的語音辨識服務。"
            return
        }

        if (recognizer == null) {
            recognizer =
                SpeechRecognizer.createSpeechRecognizer(this)
                    .also {
                        it.setRecognitionListener(this)
                    }
        }

        val intent =
            Intent(
                RecognizerIntent.ACTION_RECOGNIZE_SPEECH
            ).apply {
                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                )
                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE,
                    "zh-TW"
                )
                putExtra(
                    RecognizerIntent.EXTRA_PARTIAL_RESULTS,
                    true
                )
                putExtra(
                    RecognizerIntent.EXTRA_MAX_RESULTS,
                    3
                )
            }

        isListening = true
        micButton.text = "正在聽…"
        recognizer?.startListening(intent)
    }

    override fun onReadyForSpeech(params: Bundle?) {
        micButton.text = "我在聽"
    }

    override fun onBeginningOfSpeech() = Unit
    override fun onRmsChanged(rmsdB: Float) = Unit
    override fun onBufferReceived(buffer: ByteArray?) = Unit

    override fun onEndOfSpeech() {
        micButton.text = "處理中…"
    }

    override fun onError(error: Int) {
        isListening = false

        val label = when (error) {
            SpeechRecognizer.ERROR_NO_MATCH,
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                "沒聽到，按一下再說"

            SpeechRecognizer.ERROR_NETWORK,
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                "語音辨識網路錯誤"

            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                "麥克風權限不足"

            SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
                "語音辨識忙碌"

            else ->
                "語音辨識錯誤：$error"
        }

        micButton.text = "🎙 $label"

        if (CharlotteStateStore.continuousVoice) {
            handler.postDelayed(
                { startVoice() },
                900
            )
        }
    }

    override fun onResults(results: Bundle?) {
        isListening = false
        micButton.text = "🎙 說話"

        val text =
            results
                ?.getStringArrayList(
                    SpeechRecognizer.RESULTS_RECOGNITION
                )
                ?.firstOrNull()
                .orEmpty()
                .trim()

        if (text.isNotBlank()) {
            messageView.text =
                "你：$text\n\n夏洛特：我在想。"

            awaitingVoiceAnswer = true

            CharlotteAgentLoop.onUserVoice(
                applicationContext,
                text
            )
        } else if (
            CharlotteStateStore.continuousVoice
        ) {
            handler.postDelayed(
                { startVoice() },
                600
            )
        }
    }

    override fun onPartialResults(
        partialResults: Bundle?
    ) {
        val partial =
            partialResults
                ?.getStringArrayList(
                    SpeechRecognizer.RESULTS_RECOGNITION
                )
                ?.firstOrNull()
                .orEmpty()

        if (partial.isNotBlank()) {
            micButton.text = "你：$partial"
        }
    }

    override fun onEvent(
        eventType: Int,
        params: Bundle?
    ) = Unit

    override fun onDestroy() {
        CharlotteStateStore.conversationOpen = false

        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null

        speech.shutdown()
        scope.cancel()

        if (::scroll.isInitialized) {
            runCatching {
                windowManager.removeView(scroll)
            }
        }

        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
