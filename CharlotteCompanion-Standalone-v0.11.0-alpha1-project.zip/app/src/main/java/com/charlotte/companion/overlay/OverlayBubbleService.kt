package com.charlotte.companion.overlay

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView
import com.charlotte.companion.state.CharlotteStateStore
import kotlinx.coroutines.*

class OverlayBubbleService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var bubble: TextView
    private lateinit var close: TextView
    private lateinit var params: WindowManager.LayoutParams
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onCreate() {
        super.onCreate()

        val channel = NotificationChannel(
            "charlotte_overlay",
            "夏洛特懸浮",
            NotificationManager.IMPORTANCE_MIN
        )
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(channel)

        startForeground(
            11,
            Notification.Builder(this, "charlotte_overlay")
                .setContentTitle("夏洛特在旁邊")
                .setContentText("點符號對話；× 可關閉懸浮")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .build()
        )

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        bubble = TextView(this).apply {
            text = CharlotteStateStore.thought.value.symbol
            textSize = 22f
            gravity = Gravity.CENTER
            setPadding(28, 18, 28, 18)
            setBackgroundColor(0xD9111111.toInt())
            setTextColor(0xFFFFFFFF.toInt())
        }

        close = TextView(this).apply {
            text = "×"
            textSize = 20f
            gravity = Gravity.CENTER
            setPadding(18, 18, 18, 18)
            setBackgroundColor(0xDD2A2A2A.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            contentDescription = "關閉懸浮夏洛特"
            setOnClickListener {
                stopService(Intent(this@OverlayBubbleService, ConversationOverlayService::class.java))
                stopSelf()
            }
        }

        root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(bubble)
            addView(close)
        }

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 30
            y = 260
        }

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false

        bubble.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = params.x
                    startY = params.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) {
                        moved = true
                    }
                    params.x = startX + dx
                    params.y = startY + dy
                    windowManager.updateViewLayout(root, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        startService(
                            Intent(
                                this@OverlayBubbleService,
                                ConversationOverlayService::class.java
                            )
                        )
                    }
                    true
                }
                else -> false
            }
        }

        windowManager.addView(root, params)

        scope.launch {
            CharlotteStateStore.thought.collect {
                bubble.text = it.symbol.ifBlank { "夏" }
            }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        runCatching { windowManager.removeView(root) }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
