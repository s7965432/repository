package com.charlotte.companion.watch

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.core.content.ContextCompat

class ProjectionPermissionActivity : Activity() {
    private lateinit var manager: MediaProjectionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        manager = getSystemService(
            Context.MEDIA_PROJECTION_SERVICE
        ) as MediaProjectionManager

        startActivityForResult(
            manager.createScreenCaptureIntent(),
            REQUEST_CAPTURE
        )
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQUEST_CAPTURE &&
            resultCode == RESULT_OK &&
            data != null
        ) {
            ContextCompat.startForegroundService(
                this,
                Intent(this, ScreenWatchService::class.java).apply {
                    putExtra("resultCode", resultCode)
                    putExtra("data", data)
                }
            )
        }

        finish()
    }

    companion object {
        private const val REQUEST_CAPTURE = 7301
    }
}
