package com.charlotte.companion.agent

import android.content.Context
import android.os.SystemClock
import com.charlotte.companion.control.CharlotteAccessibilityService
import com.charlotte.companion.memory.MemoryStore
import com.charlotte.companion.lm.CharlotteLanguageLearningStore
import com.charlotte.companion.lm.CharlotteLocalLanguageModel
import com.charlotte.companion.lm.CharlotteLocalModelManager
import com.charlotte.companion.model.*
import com.charlotte.companion.prefs.CharlottePrefs
import com.charlotte.companion.remote.AiGatewayClient
import com.charlotte.companion.state.CharlotteStateStore
import kotlinx.coroutines.*
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicBoolean

object CharlotteAgentLoop {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val watcherBusy = AtomicBoolean(false)
    private val deepBusy = AtomicBoolean(false)

    @Volatile private var latestFrameBase64: String? = null
    @Volatile private var lastFrameHash = 0
    @Volatile private var lastWatcherAt = 0L
    @Volatile private var lastDeepAt = 0L
    @Volatile private var lastProactiveMessage = ""
    @Volatile private var warnedNoKey = false
    @Volatile private var queuedVoiceText: String? = null

    private const val WATCH_INTERVAL_CHANGED = 4000L
    private const val WATCH_INTERVAL_STATIC = 12000L
    private const val PROACTIVE_COOLDOWN = 25000L

    fun onFrame(context: Context, jpegBase64: String) {
        val appContext = context.applicationContext
        latestFrameBase64 = jpegBase64

        val frameHash = jpegBase64.hashCode()
        val changed = frameHash != lastFrameHash
        lastFrameHash = frameHash

        val now = SystemClock.elapsedRealtime()
        val interval = if (changed) WATCH_INTERVAL_CHANGED else WATCH_INTERVAL_STATIC
        if (now - lastWatcherAt < interval) return
        lastWatcherAt = now

        runWatcher(appContext)
    }

    fun onUserVoice(context: Context, text: String) {
        val cleaned = text.trim()
        if (cleaned.isBlank()) return
        val appContext = context.applicationContext
        MemoryStore.addTurn(appContext, "你", cleaned)

        if (CharlottePrefs.isLanguageLearning(appContext)) {
            CharlotteLanguageLearningStore.addUserSample(
                appContext,
                cleaned
            )
        }

        if (CharlotteLocalModelManager.isReady(appContext)) {
            runLocalLanguage(
                appContext,
                cleaned,
                CharlotteStateStore.watchSummary.value
            )
            return
        }

        if (deepBusy.get()) {
            queuedVoiceText = cleaned
            CharlotteStateStore.updateAiStatus("等我一下，我正在接上一句")
            return
        }

        runDeep(appContext, cleaned, CharlotteStateStore.watchSummary.value, true)
    }


    private fun runLocalLanguage(
        context: Context,
        userText: String,
        watcherSummary: String
    ) {
        if (!deepBusy.compareAndSet(false, true)) {
            queuedVoiceText = userText
            CharlotteStateStore.updateAiStatus("Charlotte-LM 正在接上一句")
            return
        }

        scope.launch {
            try {
                CharlotteStateStore.updateAiStatus("Charlotte-LM 正在想")

                val reply = CharlotteLocalLanguageModel.reply(
                    context = context,
                    userText = userText,
                    watcherSummary = watcherSummary
                )

                MemoryStore.addTurn(
                    context,
                    "夏洛特",
                    reply
                )

                CharlotteStateStore.updateThought(
                    AgentThought(
                        symbol = "夏",
                        message = reply,
                        speak = true
                    )
                )

                CharlotteStateStore.updateAiStatus(
                    "Charlotte-LM 本機運作中"
                )
            } catch (t: Throwable) {
                val msg = t.message.orEmpty()
                    .ifBlank { "本機語言模型錯誤" }
                    .take(240)

                CharlotteStateStore.updateLocalLmStatus(
                    "Charlotte-LM：$msg"
                )
                CharlotteStateStore.updateAiStatus(
                    "Charlotte-LM 暫時不可用"
                )
                CharlotteStateStore.updateThought(
                    AgentThought(
                        symbol = "！",
                        message = "我的本機語言核心剛剛卡住了：$msg",
                        speak = false
                    )
                )
            } finally {
                deepBusy.set(false)

                val queued = queuedVoiceText
                queuedVoiceText = null

                if (!queued.isNullOrBlank()) {
                    delay(120)
                    onUserVoice(context, queued)
                }
            }
        }
    }

    fun executePendingAction(context: Context): Boolean {
        val action = CharlotteStateStore.pendingAction ?: return false
        if (action.risk == RiskLevel.HIGH) return false

        val ok = CharlotteAccessibilityService.instance?.execute(action) ?: false
        if (ok) {
            CharlotteStateStore.updateThought(
                AgentThought(
                    symbol = "…",
                    message = "好，我做了。現在一起看結果。",
                    speak = false
                )
            )
        }
        return ok
    }

    private fun runWatcher(context: Context) {
        val frame = latestFrameBase64 ?: return
        val key = CharlottePrefs.getApiKey(context)

        if (key.isBlank()) {
            if (!warnedNoKey) {
                warnedNoKey = true
                CharlotteStateStore.updateAiStatus("尚未連上 AI")
                CharlotteStateStore.updateThought(
                    AgentThought(
                        symbol = "？",
                        message = "我已經在持續看畫面了，但還沒連上 AI。把 Gemini API Key 存進主畫面，我才能真正理解你正在做什麼。"
                    )
                )
            }
            return
        }

        warnedNoKey = false
        if (!watcherBusy.compareAndSet(false, true)) return

        scope.launch {
            try {
                CharlotteStateStore.updateAiStatus("Luna 正在看")
                val client = AiGatewayClient(key)
                val (watchModel, raw) = client.respondWithFallback(
                    preferred = listOf(
                        CharlottePrefs.getWatchModel(context),
                        "gemini-3.1-flash-lite",
                        "gemini-3-flash-preview"
                    ),
                    prompt = PromptComposer.watcher(context),
                    jpegBase64 = frame,
                    maxOutputTokens = 220
                )
                CharlotteStateStore.updateAiStatus("持續觀看中 · $watchModel")
                val watcher = parseWatcher(raw)
                CharlotteStateStore.updateWatchSummary(watcher.summary)
                CharlotteStateStore.updateAiStatus("持續觀看中")

                if (watcher.interest <= 0 && !watcher.needDeep) {
                    if (!CharlotteStateStore.conversationOpen) {
                        CharlotteStateStore.updateThought(
                            AgentThought(
                                symbol = "夏",
                                message = "我在看著。",
                                speak = false
                            )
                        )
                    }
                    return@launch
                }

                val now = SystemClock.elapsedRealtime()
                val strongEnough = watcher.interest >= 2 || watcher.needDeep
                val cooldownPassed = now - lastDeepAt >= PROACTIVE_COOLDOWN

                if (strongEnough && cooldownPassed) {
                    runDeep(context, null, watcher.summary, false)
                } else if (!CharlotteStateStore.conversationOpen) {
                    CharlotteStateStore.updateThought(
                        AgentThought(
                            symbol = watcher.symbol,
                            message = watcher.summary.ifBlank { "我注意到一點東西。" },
                            speak = false
                        )
                    )
                }
            } catch (t: Throwable) {
                val errorText = friendlyError(t)
                CharlotteStateStore.updateLastError(errorText)
                CharlotteStateStore.updateAiStatus("常駐視線失敗：$errorText")
                CharlotteStateStore.updateThought(
                    AgentThought(
                        symbol = "！",
                        message = "我剛剛看畫面時遇到錯誤：$errorText",
                        speak = false
                    )
                )
            } finally {
                watcherBusy.set(false)
            }
        }
    }

    private fun runDeep(
        context: Context,
        userText: String?,
        watcherSummary: String,
        userInitiated: Boolean
    ) {
        val frame = latestFrameBase64 ?: return
        val key = CharlottePrefs.getApiKey(context)
        if (key.isBlank()) return

        if (!deepBusy.compareAndSet(false, true)) {
            if (!userText.isNullOrBlank()) queuedVoiceText = userText
            return
        }

        scope.launch {
            try {
                CharlotteStateStore.updateAiStatus("Sol 正在想")
                val mode = CharlottePrefs.getMode(context)
                val client = AiGatewayClient(key)
                val (deepModel, raw) = client.respondWithFallback(
                    preferred = listOf(
                        CharlottePrefs.getDeepModel(context),
                        "gemini-3-flash-preview",
                        "gemini-3.1-flash-lite"
                    ),
                    prompt = PromptComposer.deep(context, mode, watcherSummary, userText),
                    jpegBase64 = frame,
                    maxOutputTokens = 700
                )

                CharlotteStateStore.updateAiStatus("持續觀看中 · $deepModel")
                val thought = parseThought(raw)
                lastDeepAt = SystemClock.elapsedRealtime()

                if (!userInitiated &&
                    thought.message == lastProactiveMessage &&
                    thought.message.isNotBlank()
                ) {
                    CharlotteStateStore.updateAiStatus("持續觀看中")
                    return@launch
                }

                if (!userInitiated) lastProactiveMessage = thought.message

                MemoryStore.addTurn(context, "夏洛特", thought.message)
                thought.memoryNote
                    ?.takeIf { it.isNotBlank() }
                    ?.let { MemoryStore.addNote(context, it) }

                CharlotteStateStore.updateThought(thought)
                CharlotteStateStore.updateAiStatus("持續觀看中")

                if (mode == AgentMode.AUTO) {
                    val action = thought.action
                    if (action != null &&
                        action.type != ActionType.NONE &&
                        action.risk == RiskLevel.LOW &&
                        !CharlotteAccessibilityService.userHasPriority()
                    ) {
                        delay(300)
                        if (!CharlotteAccessibilityService.userHasPriority()) {
                            CharlotteAccessibilityService.instance?.execute(action)
                        }
                    }
                }
            } catch (t: Throwable) {
                val errorText = friendlyError(t)
                CharlotteStateStore.updateLastError(errorText)
                CharlotteStateStore.updateAiStatus("深入思考失敗：$errorText")
                CharlotteStateStore.updateThought(
                    AgentThought(
                        symbol = "！",
                        message = "我剛剛想回你時遇到錯誤：$errorText",
                        speak = false
                    )
                )
            } finally {
                deepBusy.set(false)

                val queued = queuedVoiceText
                queuedVoiceText = null
                if (!queued.isNullOrBlank()) {
                    delay(150)
                    runDeep(
                        context = context,
                        userText = queued,
                        watcherSummary = CharlotteStateStore.watchSummary.value,
                        userInitiated = true
                    )
                }
            }
        }
    }

    private fun parseWatcher(raw: String): WatcherResult {
        val o = JSONObject(extractJson(raw))
        return WatcherResult(
            interest = o.optInt("interest", 0).coerceIn(0, 3),
            symbol = normalizeSymbol(o.optString("symbol", "夏")),
            summary = o.optString("summary", "").take(500),
            needDeep = o.optBoolean("need_deep", false),
            speak = o.optBoolean("speak", false)
        )
    }

    private fun parseThought(raw: String): AgentThought {
        val o = JSONObject(extractJson(raw))
        val actionObj = o.optJSONObject("action")

        val action = if (actionObj == null) null else {
            val type = when (actionObj.optString("type", "none").lowercase()) {
                "tap" -> ActionType.TAP
                "swipe" -> ActionType.SWIPE
                "back" -> ActionType.BACK
                "home" -> ActionType.HOME
                else -> ActionType.NONE
            }
            val risk = when (actionObj.optString("risk", "low").lowercase()) {
                "high" -> RiskLevel.HIGH
                "medium" -> RiskLevel.MEDIUM
                else -> RiskLevel.LOW
            }

            AgentAction(
                type = type,
                x = actionObj.optDouble("x", 0.0).toFloat(),
                y = actionObj.optDouble("y", 0.0).toFloat(),
                x2 = actionObj.optDouble("x2", 0.0).toFloat(),
                y2 = actionObj.optDouble("y2", 0.0).toFloat(),
                durationMs = actionObj.optLong("duration_ms", 250),
                risk = risk
            )
        }

        return AgentThought(
            symbol = normalizeSymbol(o.optString("symbol", "夏")),
            message = o.optString("message", "我在。").take(1000),
            speak = o.optBoolean("speak", false),
            action = action,
            memoryNote = if (o.isNull("memory_note")) {
                null
            } else {
                o.optString("memory_note", "").take(500)
            }
        )
    }

    private fun extractJson(raw: String): String {
        val cleaned = raw.trim()
            .removePrefix("```json")
            .removePrefix("```")
            .removeSuffix("```")
            .trim()

        val start = cleaned.indexOf('{')
        val end = cleaned.lastIndexOf('}')
        if (start < 0 || end <= start) {
            throw IllegalStateException("AI 沒有回傳 JSON")
        }
        return cleaned.substring(start, end + 1)
    }

    private fun normalizeSymbol(raw: String): String {
        val allowed = setOf("夏", "？", "！", "…", "🙂", "😮", "😑")
        return raw.trim().takeIf { it in allowed } ?: "夏"
    }

    private fun friendlyError(t: Throwable): String {
        val text = t.message.orEmpty()

        return when {
            "HTTP 400" in text -> "400：請求格式錯誤"
            "HTTP 401" in text -> "401：API Key 無效"
            "HTTP 403" in text && "denied access" in text.lowercase() ->
                "403：Google 專案被拒絕使用 Gemini API"
            "HTTP 403" in text ->
                "403：API Key 或專案沒有 Gemini API 權限"
            "HTTP 404" in text ->
                "404：目前模型在這個專案不可用"
            "HTTP 429" in text ->
                "429：免費配額或速率已達上限"
            "HTTP 500" in text || "HTTP 503" in text ->
                "Google Gemini 服務暫時異常"
            text.contains("Unable to resolve host", true) ->
                "手機目前無法連到 Google Gemini"
            text.isBlank() -> "未知錯誤"
            else -> text.take(220)
        }
    }
}
