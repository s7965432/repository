package com.charlotte.companion.voice
import android.content.Context
object VoiceStyleProfileStore {
    private const val PREFS = "charlotte_voice_style"
    fun save(context: Context, p: VoiceStyleProfile) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putFloat("pitch",p.pitchScale).putFloat("rate",p.speechRate)
            .putFloat("energy",p.energy).putFloat("pause",p.pauseRatio)
            .putInt("samples",p.samples).apply()
    }
    fun load(context: Context): VoiceStyleProfile {
        val p=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE)
        return VoiceStyleProfile(
            p.getFloat("pitch",1f),p.getFloat("rate",1f),
            p.getFloat("energy",.5f),p.getFloat("pause",.25f),
            p.getInt("samples",0)
        )
    }
}
