package com.charlotte.companion.model

enum class AgentMode { OBSERVE, ASSIST, AUTO }
enum class RiskLevel { LOW, MEDIUM, HIGH }
enum class ActionType { NONE, TAP, SWIPE, BACK, HOME }

data class AgentAction(
    val type: ActionType = ActionType.NONE,
    val x: Float = 0f,
    val y: Float = 0f,
    val x2: Float = 0f,
    val y2: Float = 0f,
    val durationMs: Long = 250,
    val risk: RiskLevel = RiskLevel.LOW
)

data class AgentThought(
    val symbol: String = "夏",
    val message: String = "我在這裡。",
    val speak: Boolean = false,
    val action: AgentAction? = null,
    val memoryNote: String? = null
)

data class WatcherResult(
    val interest: Int = 0,
    val symbol: String = "夏",
    val summary: String = "",
    val needDeep: Boolean = false,
    val speak: Boolean = false
)
