package com.charlotte.companion.voice

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.Future

class SpeechOutputController(
    private val context: Context
) : TextToSpeech.OnInitListener {

    private val tts = TextToSpeech(context.applicationContext, this)
    private val callbacks = ConcurrentHashMap<String, () -> Unit>()
    private val executor = Executors.newSingleThreadExecutor()

    @Volatile private var ready = false
    @Volatile private var cloneTask: Future<*>? = null
    @Volatile private var cloneEngine: ZipVoiceCloneEngine? = null

    init {
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit

            override fun onDone(utteranceId: String?) {
                val id = utteranceId ?: return
                callbacks.remove(id)?.invoke()
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                utteranceId?.let { callbacks.remove(it)?.invoke() }
            }
        })
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale.TAIWAN
            ready = true
        }
    }

    fun speak(
        text: String,
        onDone: (() -> Unit)? = null
    ) {
        if (text.isBlank()) {
            onDone?.invoke()
            return
        }

        interrupt()

        val engine = ZipVoiceCloneEngine(context.applicationContext)
        if (engine.isReady()) {
            cloneEngine = engine
            cloneTask = executor.submit {
                runCatching {
                    engine.speak(text, onDone)
                }.onFailure {
                    speakSystem(text, onDone)
                }
            }
            return
        }

        speakSystem(text, onDone)
    }

    private fun speakSystem(
        text: String,
        onDone: (() -> Unit)?
    ) {
        if (!ready) {
            onDone?.invoke()
            return
        }

        val id = "charlotte-${System.currentTimeMillis()}"
        if (onDone != null) callbacks[id] = onDone
        tts.speak(
            text,
            TextToSpeech.QUEUE_FLUSH,
            Bundle(),
            id
        )
    }

    fun interrupt() {
        callbacks.clear()
        tts.stop()
        cloneEngine?.stop()
        cloneEngine = null
        cloneTask?.cancel(true)
        cloneTask = null
    }

    fun shutdown() {
        interrupt()
        tts.shutdown()
        executor.shutdownNow()
    }
}
