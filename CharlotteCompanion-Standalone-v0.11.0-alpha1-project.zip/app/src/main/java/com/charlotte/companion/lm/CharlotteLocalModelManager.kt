package com.charlotte.companion.lm

import android.content.Context
import com.charlotte.companion.state.CharlotteStateStore
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

object CharlotteLocalModelManager {
    const val MODEL_NAME = "Charlotte-LM v0.1"
    const val BASE_MODEL = "Qwen2.5-0.5B-Instruct Q4_0"

    private const val MODEL_FILE = "qwen2.5-0.5b-instruct-q4_0.gguf"

    private const val MODEL_URL =
        "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/" +
            "resolve/main/qwen2.5-0.5b-instruct-q4_0.gguf?download=true"

    private const val MODEL_SHA256 =
        "7671c0c304e6ce5a7fc577bcb12aba01e2c155cc2efd29b2213c95b18edaf6ed"

    fun modelDir(context: Context): File =
        File(context.filesDir, "charlotte-lm").apply { mkdirs() }

    fun modelFile(context: Context): File =
        File(modelDir(context), MODEL_FILE)

    fun isReady(context: Context): Boolean =
        modelFile(context).isFile && modelFile(context).length() > 300L * 1024L * 1024L

    fun install(
        context: Context,
        progress: (String) -> Unit
    ) {
        if (isReady(context)) {
            progress("$MODEL_NAME 已安裝")
            return
        }

        val target = modelFile(context)
        val temp = File(target.parentFile, "$MODEL_FILE.part")

        progress("下載 $MODEL_NAME（約 429 MB）")
        download(MODEL_URL, temp) { done, total ->
            val doneMb = done / 1024L / 1024L
            val totalMb = if (total > 0) total / 1024L / 1024L else 0L
            if (totalMb > 0) progress("語言模型下載：$doneMb / $totalMb MB")
            else progress("語言模型下載：$doneMb MB")
        }

        progress("校驗語言模型")
        require(sha256(temp) == MODEL_SHA256) {
            "語言模型 SHA-256 校驗失敗"
        }

        if (target.exists()) target.delete()
        require(temp.renameTo(target)) {
            "無法啟用語言模型"
        }

        progress("$MODEL_NAME 安裝完成")
        CharlotteStateStore.updateLocalLmStatus("$MODEL_NAME 已安裝")
    }

    private fun download(
        url: String,
        target: File,
        progress: (Long, Long) -> Unit
    ) {
        target.parentFile?.mkdirs()

        val connection = URL(url).openConnection() as HttpURLConnection
        connection.instanceFollowRedirects = true
        connection.connectTimeout = 20000
        connection.readTimeout = 60000
        connection.setRequestProperty("User-Agent", "CharlotteCompanion/0.11")

        val code = connection.responseCode
        require(code in 200..299) {
            "語言模型下載失敗 HTTP $code"
        }

        val total = connection.contentLengthLong
        var done = 0L
        var lastReport = 0L

        connection.inputStream.use { input ->
            FileOutputStream(target, false).use { output ->
                val buf = ByteArray(1024 * 1024)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    output.write(buf, 0, n)
                    done += n

                    if (done - lastReport >= 5L * 1024L * 1024L) {
                        lastReport = done
                        progress(done, total)
                    }
                }
            }
        }

        connection.disconnect()
        progress(done, total)
    }

    private fun sha256(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buf = ByteArray(1024 * 1024)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}
