package com.charlotte.companion.lm

import android.content.Context
import android.os.PowerManager
import com.arm.aichat.AiChat
import com.arm.aichat.InferenceEngine
import com.charlotte.companion.memory.MemoryStore
import com.charlotte.companion.model.AgentMode
import com.charlotte.companion.prefs.CharlottePrefs
import com.charlotte.companion.state.CharlotteStateStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.withTimeout
import java.util.concurrent.atomic.AtomicBoolean

object CharlotteLocalLanguageModel {
    private val busy = AtomicBoolean(false)
    private var loadedPath: String? = null
    private var systemPromptSet = false

    fun isBusy(): Boolean = busy.get()

    suspend fun reply(
        context: Context,
        userText: String,
        watcherSummary: String
    ): String {
        val app = context.applicationContext
        require(CharlotteLocalModelManager.isReady(app)) {
            "本機語言模型尚未下載"
        }

        val power = app.getSystemService(PowerManager::class.java)
        if (power.currentThermalStatus >= PowerManager.THERMAL_STATUS_SEVERE) {
            throw IllegalStateException("手機溫度偏高，夏洛特先暫停本機推理")
        }

        if (!busy.compareAndSet(false, true)) {
            throw IllegalStateException("夏洛特正在處理上一句")
        }

        try {
            val engine = AiChat.getInferenceEngine(app)
            ensureLoaded(app, engine)

            val memory = MemoryStore.recentContext(app)
            val learning = if (CharlottePrefs.isLanguageLearning(app)) {
                CharlotteLanguageLearningStore.recentStyleContext(app)
            } else {
                ""
            }

            val mode = CharlottePrefs.getMode(app)
            val pkg = CharlotteStateStore.currentPackage.value ?: "未知"

            val prompt = buildString {
                appendLine("目前模式：${mode.name}")
                appendLine("目前前景套件：$pkg")
                appendLine("目前畫面摘要：${watcherSummary.ifBlank { "沒有可靠摘要" }}")
                if (memory.isNotBlank()) {
                    appendLine()
                    appendLine(memory)
                }
                if (learning.isNotBlank()) {
                    appendLine()
                    appendLine(learning)
                }
                appendLine()
                appendLine("使用者：${userText.trim()}")
                appendLine()
                append(
                    "直接用繁體中文自然回答。不要自稱模型，不要寫分析過程，" +
                        "不要每句都解釋系統限制。通常 1～4 句；需要時再多說。"
                )
            }

            val tokens = engine.sendUserPrompt(
                prompt,
                predictLength = 220
            ).toList()

            val text = tokens.joinToString("").trim()

            if (text.isBlank()) {
                throw IllegalStateException("本機語言模型沒有產生文字")
            }

            return text.take(1200)
        } finally {
            busy.set(false)
        }
    }

    suspend fun test(context: Context): String {
        val app = context.applicationContext
        val engine = AiChat.getInferenceEngine(app)
        ensureLoaded(app, engine)

        val out = engine.sendUserPrompt(
            "只回答：夏洛特本機語言核心已連上",
            predictLength = 48
        ).toList().joinToString("").trim()

        return out.ifBlank { "本機模型沒有輸出" }
    }

    private suspend fun ensureLoaded(
        context: Context,
        engine: InferenceEngine
    ) {
        val model = CharlotteLocalModelManager.modelFile(context)
        val path = model.absolutePath

        if (loadedPath == path &&
            engine.state.value is InferenceEngine.State.ModelReady
        ) {
            return
        }

        when (engine.state.value) {
            is InferenceEngine.State.Uninitialized,
            is InferenceEngine.State.Initializing -> {
                withTimeout(20000) {
                    engine.state.first {
                        it is InferenceEngine.State.Initialized ||
                            it is InferenceEngine.State.Error
                    }
                }
            }
            is InferenceEngine.State.Error -> {
                runCatching { engine.cleanUp() }
            }
            else -> Unit
        }

        if (engine.state.value is InferenceEngine.State.ModelReady) {
            runCatching { engine.cleanUp() }
        }

        CharlotteStateStore.updateLocalLmStatus("正在載入 Charlotte-LM")
        engine.loadModel(path)
        loadedPath = path
        systemPromptSet = false

        if (!systemPromptSet) {
            engine.setSystemPrompt(
                """
你就是夏洛特。
你和使用者共用同一支 Android 手機。
你的回答要自然、有自己的判斷，不要系統腔，不要把自己和夏洛特分開。
使用者直接說話時就回答；不知道的事情不要硬編。
語氣以繁體中文為主，可以自然口語，但不要機械重複使用者句型。
這個本機核心負責語言、人格、記憶與決策文字；畫面資訊只採用系統提供的可靠摘要。
                """.trimIndent()
            )
            systemPromptSet = true
        }

        CharlotteStateStore.updateLocalLmStatus(
            "${CharlotteLocalModelManager.MODEL_NAME} 已載入"
        )
    }
}
