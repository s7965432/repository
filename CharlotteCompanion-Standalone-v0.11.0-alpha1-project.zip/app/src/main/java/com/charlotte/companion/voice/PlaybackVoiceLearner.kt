package com.charlotte.companion.voice
import android.media.*
import android.media.projection.MediaProjection
import android.os.Build
import com.charlotte.companion.state.CharlotteStateStore
import kotlinx.coroutines.*

class PlaybackVoiceLearner(
    private val projection:MediaProjection,
    private val onProfileReady:(VoiceStyleProfile)->Unit
){
    private val scope=CoroutineScope(SupervisorJob()+Dispatchers.IO)
    private var record:AudioRecord?=null
    private var job:Job?=null
    private val analyzer=VoiceStyleAnalyzer(SAMPLE_RATE)

    fun start():Boolean{
        if(Build.VERSION.SDK_INT<29){
            CharlotteStateStore.updateVoiceLearningStatus("此 Android 版本不支援系統播放音訊學習")
            return false
        }
        val config=AudioPlaybackCaptureConfiguration.Builder(projection)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME).build()
        val format=AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(SAMPLE_RATE).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build()
        val min=AudioRecord.getMinBufferSize(SAMPLE_RATE,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT).coerceAtLeast(SAMPLE_RATE)
        record=try{AudioRecord.Builder().setAudioFormat(format).setAudioPlaybackCaptureConfig(config).setBufferSizeInBytes(min*2).build()}
        catch(t:Throwable){
            CharlotteStateStore.updateVoiceLearningStatus("這個 App/內容目前不允許播放音訊擷取")
            return false
        }
        val r=record?:return false
        job=scope.launch{
            val buf=ShortArray(2048)
            try{
                r.startRecording()
                CharlotteStateStore.updateVoiceLearning(true)
                CharlotteStateStore.updateVoiceLearningStatus("學習中：播放角色語音，我會學音高、語速與停頓")
                while(isActive){
                    val n=r.read(buf,0,buf.size,AudioRecord.READ_BLOCKING)
                    if(n>0)analyzer.addPcm16(buf,n) else if(n<0)break
                }
            }catch(t:Throwable){
                CharlotteStateStore.updateVoiceLearningStatus("語音學習失敗：${t.message?.take(100)?:"未知錯誤"}")
            }finally{
                runCatching{r.stop()}
                onProfileReady(analyzer.buildProfile())
                CharlotteStateStore.updateVoiceLearning(false)
            }
        }
        return true
    }
    fun stop(){
        job?.cancel();job=null
        runCatching{record?.stop()};record?.release();record=null
    }
    companion object{private const val SAMPLE_RATE=16000}
}
