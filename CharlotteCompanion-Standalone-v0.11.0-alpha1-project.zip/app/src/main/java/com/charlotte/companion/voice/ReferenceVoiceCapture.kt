package com.charlotte.companion.voice

import android.content.Context
import android.media.*
import android.media.projection.MediaProjection
import android.os.Build
import com.charlotte.companion.state.CharlotteStateStore
import kotlinx.coroutines.*
import java.io.BufferedOutputStream
import java.io.FileOutputStream

class ReferenceVoiceCapture(
    private val context: Context,
    private val projection: MediaProjection,
    private val onSaved: (pcmFile: java.io.File, wavFile: java.io.File, sampleRate: Int) -> Unit
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var audioRecord: AudioRecord? = null
    private var job: Job? = null

    fun start(): Boolean {
        if (Build.VERSION.SDK_INT < 29) {
            CharlotteStateStore.updateVoiceLearningStatus(
                "此 Android 版本不支援系統播放音訊擷取"
            )
            return false
        }

        if (job != null) return true

        val config = AudioPlaybackCaptureConfiguration.Builder(projection)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()

        val format = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(SAMPLE_RATE)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()

        val minBuffer = AudioRecord.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(SAMPLE_RATE)

        val recorder = try {
            AudioRecord.Builder()
                .setAudioFormat(format)
                .setAudioPlaybackCaptureConfig(config)
                .setBufferSizeInBytes(minBuffer * 2)
                .build()
        } catch (t: Throwable) {
            CharlotteStateStore.updateVoiceLearningStatus(
                "這個 App/內容目前不允許播放音訊擷取"
            )
            return false
        }

        audioRecord = recorder

        val pcm = VoiceCloneStore.referencePcm(context)
        val wav = VoiceCloneStore.referenceWav(context)
        pcm.parentFile?.mkdirs()

        job = scope.launch {
            val buffer = ShortArray(2048)
            var capturedSamples = 0L

            try {
                BufferedOutputStream(FileOutputStream(pcm, false)).use { out ->
                    recorder.startRecording()

                    CharlotteStateStore.updateVoiceLearning(true)
                    CharlotteStateStore.updateVoiceLearningStatus(
                        "正在錄角色原聲：請只播放想學的角色，建議 5～15 秒"
                    )

                    while (isActive) {
                        val n = recorder.read(
                            buffer,
                            0,
                            buffer.size,
                            AudioRecord.READ_BLOCKING
                        )

                        if (n <= 0) {
                            if (n < 0) {
                                CharlotteStateStore.updateVoiceLearningStatus(
                                    "角色原聲擷取失敗：$n"
                                )
                            }
                            break
                        }

                        for (i in 0 until n) {
                            val v = buffer[i].toInt()
                            out.write(v and 0xff)
                            out.write((v ushr 8) and 0xff)
                        }

                        capturedSamples += n

                        // Cap one reference at ~20 s.
                        if (capturedSamples >= SAMPLE_RATE * 20L) break
                    }
                }
            } finally {
                runCatching { recorder.stop() }
                    .onFailure { }
                runCatching { recorder.release() }
                audioRecord = null

                if (pcm.length() > SAMPLE_RATE * 2L) {
                    WavUtil.pcm16ToWav(
                        pcm = pcm,
                        wav = wav,
                        sampleRate = SAMPLE_RATE,
                        channels = 1
                    )
                    onSaved(pcm, wav, SAMPLE_RATE)
                } else {
                    CharlotteStateStore.updateVoiceLearningStatus(
                        "沒有抓到足夠角色語音"
                    )
                }

                CharlotteStateStore.updateVoiceLearning(false)
            }
        }

        return true
    }

    fun stop() {
        job?.cancel()
        job = null
        runCatching { audioRecord?.stop() }
        audioRecord?.release()
        audioRecord = null
    }

    companion object {
        const val SAMPLE_RATE = 16000
    }
}
