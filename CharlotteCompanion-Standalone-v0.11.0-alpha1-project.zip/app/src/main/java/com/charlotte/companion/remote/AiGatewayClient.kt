package com.charlotte.companion.remote

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class AiGatewayClient(private val apiKey: String) {

    data class ModelInfo(
        val id: String,
        val displayName: String,
        val supportsGenerateContent: Boolean
    )

    data class TestResult(
        val chosenModel: String,
        val text: String
    )

    fun listModels(): List<ModelInfo> {
        val connection = URL(
            "https://generativelanguage.googleapis.com/v1beta/models?pageSize=100"
        ).openConnection() as HttpURLConnection

        connection.requestMethod = "GET"
        connection.connectTimeout = 15000
        connection.readTimeout = 30000
        connection.setRequestProperty("x-goog-api-key", apiKey)
        connection.setRequestProperty("Accept", "application/json")

        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
        connection.disconnect()

        if (code !in 200..299) {
            throw IllegalStateException(parseHttpError(code, raw))
        }

        val root = JSONObject(raw)
        val models = root.optJSONArray("models") ?: JSONArray()
        val result = mutableListOf<ModelInfo>()

        for (i in 0 until models.length()) {
            val item = models.optJSONObject(i) ?: continue
            val rawName = item.optString("name", "")
            val id = rawName.removePrefix("models/")
            if (id.isBlank()) continue

            val methods = item.optJSONArray("supportedGenerationMethods") ?: JSONArray()
            var canGenerate = false
            for (j in 0 until methods.length()) {
                if (methods.optString(j) == "generateContent") {
                    canGenerate = true
                    break
                }
            }

            result += ModelInfo(
                id = id,
                displayName = item.optString("displayName", id),
                supportsGenerateContent = canGenerate
            )
        }

        return result
    }

    fun chooseAvailableModel(preferred: List<String>): String {
        val available = listModels()
            .filter { it.supportsGenerateContent }
            .map { it.id }
            .toSet()

        preferred.firstOrNull { it in available }?.let { return it }

        // Last-resort: pick a Flash model that actually exists for this key/project.
        return available
            .filter { "flash" in it && "image" !in it && "live" !in it && "tts" !in it }
            .sortedDescending()
            .firstOrNull()
            ?: throw IllegalStateException("這個 Google 專案目前沒有可用的 Gemini generateContent 模型")
    }

    fun test(preferred: List<String>): TestResult {
        val chosen = chooseAvailableModel(preferred)
        val text = request(
            model = chosen,
            prompt = "Reply with exactly: CHARLOTTE_OK",
            jpegBase64 = null,
            maxOutputTokens = 32,
            jsonOutput = false
        )
        return TestResult(chosen, text)
    }

    fun respondWithFallback(
        preferred: List<String>,
        prompt: String,
        jpegBase64: String,
        maxOutputTokens: Int = 500
    ): Pair<String, String> {
        val chosen = chooseAvailableModel(preferred)
        val text = request(
            model = chosen,
            prompt = prompt,
            jpegBase64 = jpegBase64,
            maxOutputTokens = maxOutputTokens,
            jsonOutput = true
        )
        return chosen to text
    }

    private fun request(
        model: String,
        prompt: String,
        jpegBase64: String?,
        maxOutputTokens: Int,
        jsonOutput: Boolean
    ): String {
        val connection = URL(
            "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
        ).openConnection() as HttpURLConnection

        connection.requestMethod = "POST"
        connection.connectTimeout = 15000
        connection.readTimeout = 45000
        connection.doOutput = true
        connection.setRequestProperty("x-goog-api-key", apiKey)
        connection.setRequestProperty("Content-Type", "application/json")
        connection.setRequestProperty("Accept", "application/json")

        val parts = JSONArray()
            .put(JSONObject().put("text", prompt))

        if (!jpegBase64.isNullOrBlank()) {
            parts.put(
                JSONObject().put(
                    "inline_data",
                    JSONObject()
                        .put("mime_type", "image/jpeg")
                        .put("data", jpegBase64)
                )
            )
        }

        val generationConfig = JSONObject()
            .put("maxOutputTokens", maxOutputTokens)

        if (jsonOutput) {
            generationConfig.put("responseMimeType", "application/json")
        }

        val body = JSONObject()
            .put(
                "contents",
                JSONArray().put(
                    JSONObject()
                        .put("role", "user")
                        .put("parts", parts)
                )
            )
            .put("generationConfig", generationConfig)

        connection.outputStream.use {
            it.write(body.toString().toByteArray(Charsets.UTF_8))
        }

        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
        connection.disconnect()

        if (code !in 200..299) {
            throw IllegalStateException(parseHttpError(code, raw))
        }

        val root = JSONObject(raw)
        val candidates = root.optJSONArray("candidates") ?: JSONArray()

        if (candidates.length() == 0) {
            val block = root.optJSONObject("promptFeedback")
                ?.optString("blockReason", "")
                .orEmpty()

            if (block.isNotBlank()) {
                throw IllegalStateException("Gemini blocked: $block")
            }

            throw IllegalStateException("Gemini 沒有回傳候選內容")
        }

        val content = candidates.optJSONObject(0)?.optJSONObject("content")
            ?: throw IllegalStateException("Gemini 回覆缺少 content")

        val outParts = content.optJSONArray("parts") ?: JSONArray()
        val text = buildString {
            for (i in 0 until outParts.length()) {
                val t = outParts.optJSONObject(i)?.optString("text", "").orEmpty()
                if (t.isNotBlank()) append(t)
            }
        }.trim()

        if (text.isBlank()) {
            throw IllegalStateException("Gemini 回覆沒有文字內容")
        }

        return text
    }

    private fun parseHttpError(code: Int, raw: String): String {
        val parsed = runCatching {
            val root = JSONObject(raw)
            val error = root.optJSONObject("error")
            val status = error?.optString("status", "")?.ifBlank { "ERROR" } ?: "ERROR"
            val message = error?.optString("message", "")?.ifBlank { raw.take(400) }
                ?: raw.take(400)
            "Gemini HTTP $code $status: $message"
        }.getOrElse {
            "Gemini HTTP $code: ${raw.take(400).ifBlank { "未知錯誤" }}"
        }

        return parsed
    }
}
