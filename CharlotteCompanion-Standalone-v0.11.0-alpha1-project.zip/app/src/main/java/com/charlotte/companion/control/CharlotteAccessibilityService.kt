package com.charlotte.companion.control

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import com.charlotte.companion.model.ActionType
import com.charlotte.companion.model.AgentAction
import com.charlotte.companion.state.CharlotteStateStore

class CharlotteAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: CharlotteAccessibilityService? = null
        @Volatile private var lastUserTouchAt: Long = 0L
        @Volatile private var selfGestureUntil: Long = 0L

        fun userHasPriority(): Boolean {
            return SystemClock.uptimeMillis() - lastUserTouchAt < 1600L
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        CharlotteStateStore.updateCurrentPackage(event?.packageName?.toString())

        if (event?.eventType == AccessibilityEvent.TYPE_TOUCH_INTERACTION_START) {
            val now = SystemClock.uptimeMillis()
            if (now > selfGestureUntil) {
                lastUserTouchAt = now
            }
        }
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    fun execute(action: AgentAction): Boolean {
        if (CharlotteStateStore.currentPackage.value == packageName) return false

        return when (action.type) {
            ActionType.NONE -> false
            ActionType.TAP -> tapNormalized(action.x, action.y)
            ActionType.SWIPE -> swipeNormalized(
                action.x, action.y, action.x2, action.y2, action.durationMs
            )
            ActionType.BACK -> performGlobalAction(GLOBAL_ACTION_BACK)
            ActionType.HOME -> performGlobalAction(GLOBAL_ACTION_HOME)
        }
    }

    private fun tapNormalized(nx: Float, ny: Float): Boolean {
        val dm = resources.displayMetrics
        val x = nx.coerceIn(0f, 1f) * dm.widthPixels
        val y = ny.coerceIn(0f, 1f) * dm.heightPixels
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 80)
        selfGestureUntil = SystemClock.uptimeMillis() + 500L
        return dispatchGesture(
            GestureDescription.Builder().addStroke(stroke).build(),
            null,
            null
        )
    }

    private fun swipeNormalized(
        nx1: Float,
        ny1: Float,
        nx2: Float,
        ny2: Float,
        duration: Long
    ): Boolean {
        val dm = resources.displayMetrics
        val path = Path().apply {
            moveTo(
                nx1.coerceIn(0f, 1f) * dm.widthPixels,
                ny1.coerceIn(0f, 1f) * dm.heightPixels
            )
            lineTo(
                nx2.coerceIn(0f, 1f) * dm.widthPixels,
                ny2.coerceIn(0f, 1f) * dm.heightPixels
            )
        }
        val dur = duration.coerceIn(80, 3000)
        selfGestureUntil = SystemClock.uptimeMillis() + dur + 500L
        val stroke = GestureDescription.StrokeDescription(path, 0, dur)
        return dispatchGesture(
            GestureDescription.Builder().addStroke(stroke).build(),
            null,
            null
        )
    }
}
