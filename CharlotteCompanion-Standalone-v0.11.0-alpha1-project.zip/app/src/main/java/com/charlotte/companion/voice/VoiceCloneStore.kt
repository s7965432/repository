package com.charlotte.companion.voice

import android.content.Context
import java.io.File

object VoiceCloneStore {
    private const val PREFS = "charlotte_voice_clone"
    private const val KEY_REFERENCE_TEXT = "reference_text"

    fun root(context: Context): File =
        File(context.filesDir, "voice-clone").apply { mkdirs() }

    fun referencePcm(context: Context): File =
        File(root(context), "reference.pcm")

    fun referenceWav(context: Context): File =
        File(root(context), "reference.wav")

    fun setReferenceText(context: Context, text: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_REFERENCE_TEXT, text.trim()).apply()
    }

    fun referenceText(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_REFERENCE_TEXT, "") ?: ""

    fun hasReference(context: Context): Boolean =
        referenceWav(context).isFile &&
            referenceWav(context).length() > 44 &&
            referenceText(context).isNotBlank()
}
