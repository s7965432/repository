package com.charlotte.companion.voice

import android.content.Context
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

object ZipVoiceModelManager {
    private const val MODEL_URL =
        "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/" +
            "sherpa-onnx-zipvoice-distill-int8-zh-en-emilia.tar.bz2"

    private const val VOCODER_URL =
        "https://github.com/k2-fsa/sherpa-onnx/releases/download/vocoder-models/" +
            "vocos_24khz.onnx"

    private const val MODEL_SHA =
        "77219c8b40f4ee8d73a7f902305ff6c1128ef9b54461c41b4ca6ed890b6c2803"

    private const val VOCODER_SHA =
        "bcb3b970e384161c4d634f0bb9e999ff1c471b34c9bc0b1049a5014065ed3cc0"

    fun root(context: Context): File =
        File(context.filesDir, "zipvoice-model").apply { mkdirs() }

    fun modelDir(context: Context): File =
        File(root(context), "sherpa-onnx-zipvoice-distill-int8-zh-en-emilia")

    fun vocoder(context: Context): File =
        File(root(context), "vocos_24khz.onnx")

    fun isReady(context: Context): Boolean {
        val m = modelDir(context)
        return File(m, "tokens.txt").isFile &&
            File(m, "encoder.int8.onnx").isFile &&
            File(m, "decoder.int8.onnx").isFile &&
            File(m, "lexicon.txt").isFile &&
            File(m, "espeak-ng-data").isDirectory &&
            vocoder(context).isFile
    }

    fun install(
        context: Context,
        progress: (String) -> Unit
    ) {
        if (isReady(context)) {
            progress("音色模型已安裝")
            return
        }

        val root = root(context)
        val archive = File(root, "zipvoice.tar.bz2")
        val vocoder = vocoder(context)

        progress("下載音色模型 1/2（約 109 MB）")
        download(MODEL_URL, archive)
        require(sha256(archive) == MODEL_SHA) {
            "ZipVoice 模型校驗失敗"
        }

        progress("解壓 ZipVoice 模型")
        extractTarBz2(archive, root)
        archive.delete()

        progress("下載音色模型 2/2（約 54 MB）")
        download(VOCODER_URL, vocoder)
        require(sha256(vocoder) == VOCODER_SHA) {
            "Vocoder 校驗失敗"
        }

        require(isReady(context)) {
            "音色模型檔案不完整"
        }

        progress("音色模型安裝完成")
    }

    private fun download(url: String, target: File) {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.instanceFollowRedirects = true
        connection.connectTimeout = 20000
        connection.readTimeout = 60000
        connection.setRequestProperty("User-Agent", "CharlotteCompanion/0.10")

        if (connection.responseCode !in 200..299) {
            throw IllegalStateException(
                "下載失敗 HTTP ${connection.responseCode}"
            )
        }

        target.parentFile?.mkdirs()
        connection.inputStream.use { input ->
            FileOutputStream(target, false).use { output ->
                input.copyTo(output)
            }
        }
        connection.disconnect()
    }

    private fun extractTarBz2(archive: File, destination: File) {
        val base = destination.canonicalFile

        TarArchiveInputStream(
            BZip2CompressorInputStream(
                BufferedInputStream(FileInputStream(archive))
            )
        ).use { tar ->
            while (true) {
                val entry = tar.nextTarEntry ?: break
                val out = File(destination, entry.name).canonicalFile

                require(out.path.startsWith(base.path + File.separator)) {
                    "模型壓縮檔路徑不安全"
                }

                if (entry.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { output ->
                        tar.copyTo(output)
                    }
                }
            }
        }
    }

    private fun sha256(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buf = ByteArray(1024 * 1024)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}
