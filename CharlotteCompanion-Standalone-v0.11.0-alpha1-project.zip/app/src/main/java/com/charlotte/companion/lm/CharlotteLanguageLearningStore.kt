package com.charlotte.companion.lm

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object CharlotteLanguageLearningStore {
    private const val PREFS = "charlotte_language_learning"
    private const val KEY_SAMPLES = "samples"
    private const val MAX_SAMPLES = 80

    fun addUserSample(context: Context, text: String) {
        val clean = text.trim().take(240)
        if (clean.length < 2) return

        val samples = load(context).toMutableList()
        if (samples.lastOrNull() == clean) return

        samples += clean
        while (samples.size > MAX_SAMPLES) samples.removeAt(0)

        val arr = JSONArray()
        samples.forEach { arr.put(it) }

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_SAMPLES, arr.toString()).apply()
    }

    fun recentStyleContext(context: Context, limit: Int = 12): String {
        val items = load(context).takeLast(limit)
        if (items.isEmpty()) return ""

        return buildString {
            appendLine("使用者近期自然說話樣本，只學語氣與用詞習慣，不要機械複製句子：")
            items.forEach { appendLine("- $it") }
        }.trim()
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().remove(KEY_SAMPLES).apply()
    }

    private fun load(context: Context): List<String> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_SAMPLES, "[]") ?: "[]"

        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length())
                .mapNotNull { arr.optString(it).takeIf(String::isNotBlank) }
        }.getOrDefault(emptyList())
    }
}
