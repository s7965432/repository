package com.charlotte.companion.voice

import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.os.Build
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.*
import java.io.File

class ReferenceAudioTranscriber(
    private val context: Context
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun transcribe(
        pcmFile: File,
        sampleRate: Int,
        onResult: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        if (Build.VERSION.SDK_INT < 33) {
            onError("此版本 Android 無法直接把播放音訊送進系統語音辨識")
            return
        }

        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError("手機沒有可用的系統語音辨識器")
            return
        }

        val pipe = ParcelFileDescriptor.createPipe()
        val readSide = pipe[0]
        val writeSide = pipe[1]

        val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        val segments = mutableListOf<String>()
        var finished = false

        fun finishSuccess(text: String) {
            if (finished) return
            finished = true
            runCatching { readSide.close() }
            recognizer.destroy()
            if (text.isBlank()) onError("自動台詞辨識沒有結果")
            else onResult(text.trim())
        }

        fun finishError(message: String) {
            if (finished) return
            finished = true
            runCatching { readSide.close() }
            recognizer.destroy()
            onError(message)
        }

        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = Unit
            override fun onBeginningOfSpeech() = Unit
            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() = Unit

            override fun onError(error: Int) {
                if (segments.isNotEmpty()) {
                    finishSuccess(segments.joinToString(" "))
                } else {
                    finishError("自動台詞辨識失敗：$error")
                }
            }

            override fun onResults(results: Bundle?) {
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                    .trim()

                finishSuccess(
                    if (text.isNotBlank()) text
                    else segments.joinToString(" ")
                )
            }

            override fun onPartialResults(partialResults: Bundle?) = Unit

            override fun onSegmentResults(segmentResults: Bundle) {
                val text = segmentResults
                    .getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                    .trim()
                if (text.isNotBlank()) segments += text
            }

            override fun onEndOfSegmentedSession() {
                finishSuccess(segments.joinToString(" "))
            }

            override fun onEvent(eventType: Int, params: Bundle?) = Unit
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "zh-TW")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)

            putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE, readSide)
            putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_CHANNEL_COUNT, 1)
            putExtra(
                RecognizerIntent.EXTRA_AUDIO_SOURCE_ENCODING,
                AudioFormat.ENCODING_PCM_16BIT
            )
            putExtra(
                RecognizerIntent.EXTRA_AUDIO_SOURCE_SAMPLING_RATE,
                sampleRate
            )
            putExtra(
                RecognizerIntent.EXTRA_SEGMENTED_SESSION,
                RecognizerIntent.EXTRA_AUDIO_SOURCE
            )
        }

        recognizer.startListening(intent)

        scope.launch {
            try {
                ParcelFileDescriptor.AutoCloseOutputStream(writeSide).use { out ->
                    pcmFile.inputStream().use { input ->
                        input.copyTo(out)
                    }
                }
            } catch (t: Throwable) {
                runCatching { writeSide.close() }
            }
        }
    }
}
