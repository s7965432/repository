package com.charlotte.companion.voice
data class VoiceStyleProfile(
    val pitchScale: Float = 1.0f,
    val speechRate: Float = 1.0f,
    val energy: Float = 0.5f,
    val pauseRatio: Float = 0.25f,
    val samples: Int = 0
)
