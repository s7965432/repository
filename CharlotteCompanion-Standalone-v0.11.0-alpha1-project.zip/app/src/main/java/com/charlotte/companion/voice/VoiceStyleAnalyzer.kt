package com.charlotte.companion.voice
import kotlin.math.sqrt
class VoiceStyleAnalyzer(private val sampleRate:Int=16000){
    private var voiced=0; private var silent=0; private var energySum=0.0
    private var pitchSum=0.0; private var pitchCount=0
    fun addPcm16(samples:ShortArray,count:Int){
        if(count<=0)return
        var ss=0.0
        for(i in 0 until count){val v=samples[i].toDouble()/32768.0; ss+=v*v}
        val rms=sqrt(ss/count).coerceIn(0.0,1.0); energySum+=rms
        if(rms<0.018){silent++;return}
        voiced++
        val p=estimatePitch(samples,count)
        if(p in 70.0..420.0){pitchSum+=p;pitchCount++}
    }
    private fun estimatePitch(s:ShortArray,count:Int):Double{
        val minLag=sampleRate/420; val maxLag=minOf(sampleRate/70,count/2)
        if(maxLag<=minLag)return 0.0
        var bestLag=0; var best=-1.0
        for(lag in minLag..maxLag step 2){
            var score=0.0;var a2=0.0;var b2=0.0;var i=0
            while(i+lag<count){
                val a=s[i].toDouble();val b=s[i+lag].toDouble()
                score+=a*b;a2+=a*a;b2+=b*b;i+=2
            }
            val d=sqrt(a2*b2)
            if(d>0){val n=score/d;if(n>best){best=n;bestLag=lag}}
        }
        return if(bestLag>0&&best>0.28) sampleRate.toDouble()/bestLag else 0.0
    }
    fun buildProfile():VoiceStyleProfile{
        val total=voiced+silent
        if(total==0)return VoiceStyleProfile()
        val meanPitch=if(pitchCount>0)pitchSum/pitchCount else 180.0
        val pause=silent.toFloat()/total
        return VoiceStyleProfile(
            pitchScale=(meanPitch/180.0).toFloat().coerceIn(.72f,1.28f),
            speechRate=(1.12f-pause*.55f).coerceIn(.82f,1.18f),
            energy=(energySum/total).toFloat().coerceIn(0f,1f),
            pauseRatio=pause.coerceIn(0f,1f), samples=total
        )
    }
}
