# Third-party notices

## llama.cpp
Project: https://github.com/ggml-org/llama.cpp
Pinned build source commit:
`9dcf84e5ae2718947188b539aab8b9c2b15d3ba1`

Used for local GGUF inference on Android.

## Qwen2.5-0.5B-Instruct-GGUF
Project:
`Qwen/Qwen2.5-0.5B-Instruct-GGUF`

The Charlotte-LM v0.1 runtime downloads:
`qwen2.5-0.5b-instruct-q4_0.gguf`

Model license: Apache-2.0.

## sherpa-onnx / ZipVoice
Used by the existing on-device reference voice cloning layer.

Third-party licenses and model terms remain their original licenses.
