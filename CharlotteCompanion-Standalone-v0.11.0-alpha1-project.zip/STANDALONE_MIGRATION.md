# 獨立專案搬移
applicationId 仍是 `com.charlotte.companion`，所以是同一個 Android App。
若搬到全新 GitHub repository，需保留同一簽章金鑰才能直接覆蓋既有版本。
