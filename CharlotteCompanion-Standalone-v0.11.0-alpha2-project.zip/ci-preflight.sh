#!/usr/bin/env bash
set -euo pipefail

test -f gradle.properties
grep -q "android.useAndroidX=true" gradle.properties

grep -q 'versionName = "0.11.0-alpha2"' app/build.gradle.kts
grep -q 'versionCode = 1102' app/build.gradle.kts
grep -q 'minSdk = 33' app/build.gradle.kts
grep -q 'implementation(project(":llama-lib"))' app/build.gradle.kts
grep -q 'include(":llama-lib")' settings.gradle.kts

test -f llama-lib/src/main/java/com/arm/aichat/AiChat.kt
test -f llama-lib/src/main/cpp/ai_chat.cpp
test -d llama.cpp-source

test -f app/src/main/java/com/charlotte/companion/lm/CharlotteLocalModelManager.kt
test -f app/src/main/java/com/charlotte/companion/lm/CharlotteLocalLanguageModel.kt
test -f app/src/main/java/com/charlotte/companion/watch/ProjectionPermissionActivity.kt

grep -q 'btnDownloadLocalLm' app/src/main/res/layout/activity_main.xml
grep -q 'ProjectionPermissionActivity' app/src/main/AndroidManifest.xml
grep -q 'THERMAL_STATUS_SEVERE' app/src/main/java/com/charlotte/companion/watch/ScreenWatchService.kt
grep -q 'CharlotteLocalModelManager.isReady' app/src/main/java/com/charlotte/companion/agent/CharlotteAgentLoop.kt

test -f app/libs/sherpa-onnx-1.13.7.aar

echo "PRECHECK=PASS"
