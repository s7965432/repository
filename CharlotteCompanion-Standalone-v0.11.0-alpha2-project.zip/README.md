# 夏洛特共用手機模式 — Standalone v0.11.0-alpha2

這版把「真正使用時需要的功能」搬到懸浮夏洛特，主畫面不再是主要操作入口。

## 懸浮介面現在包含
- 文字輸入
- 麥克風
- 連續語音
- 開始保持觀看
- 停止保持觀看
- 開啟 Accessibility 操作權限
- 觀察 / 輔助 / 自動
- 下載 / 測試 Charlotte-LM
- 語言學習開關
- Gemini API Key 儲存 / 測試（只保留給雲端視覺，可選）
- 下載音色模型
- 角色參考台詞
- 開始 / 停止擷取角色原聲
- 語音輸出測試
- 執行待處理動作
- 縮回 / 關閉懸浮

「開始保持觀看」會從懸浮層叫出透明 MediaProjection 授權 Activity。
授權完成後立刻回到原本正在使用的 App，不需要把夏洛特主畫面留在前景。

## Charlotte-LM v0.1
這版開始接入本機語言核心。

基礎權重：
- Qwen2.5-0.5B-Instruct GGUF Q4_0
- Apache-2.0
- 約 429 MB
- llama.cpp Android runtime

夏洛特自己的部分：
- 固定本機人格 system prompt
- 本機 MemoryStore
- 語言學習樣本
- 使用者語氣 / 用詞細微學習
- 當本機模型已安裝時，語音與文字對話優先走本機，不再要求 Gemini API Key

這不是宣稱從零訓練一個 0.5B 基礎模型。
v0.1 是「開放基礎權重 + 夏洛特自己的本機人格 / 記憶 / 語言學習層」。
後續可以再把累積的學習資料整理成 LoRA / 微調資料集。

## 溫控
舊版固定高頻截圖容易發熱。

v0.11 改成：
- MediaProjection capture width 上限 720
- JPEG 再縮到 540
- 平常約 1.5 秒一次
- 溫熱約 3.5 秒
- 偏熱約 6 秒
- 臨界過熱約 9 秒
- 本機 LLM 在 Android thermal status >= SEVERE 時暫停推理

目的不是把手機燒熱來換速度，而是讓夏洛特能長時間掛著。

## 尚未等同「完整本機視覺模型」
Charlotte-LM v0.1 是語言 / 人格 / 記憶核心。
畫面像素的深度理解仍是另一層；目前 Gemini watcher 可保留當可選視覺來源。
下一階段會把視覺也改成本機或混合低耗能方案。


## alpha2 build repair

- 修正 llama.cpp Android bridge 編譯遺漏 `logging.h`。
- 主 APK 功能與 alpha1 相同；這輪先讓主程式恢復可編譯。
