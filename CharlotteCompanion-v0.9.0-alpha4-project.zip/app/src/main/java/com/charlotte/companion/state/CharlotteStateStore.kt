package com.charlotte.companion.state

import com.charlotte.companion.model.AgentAction
import com.charlotte.companion.model.AgentThought
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

object CharlotteStateStore {
    private val _thought = MutableStateFlow(AgentThought())
    val thought = _thought.asStateFlow()

    private val _currentPackage = MutableStateFlow<String?>(null)
    val currentPackage = _currentPackage.asStateFlow()

    private val _watching = MutableStateFlow(false)
    val watching = _watching.asStateFlow()

    private val _aiStatus = MutableStateFlow("尚未連線")
    val aiStatus = _aiStatus.asStateFlow()

    private val _watchSummary = MutableStateFlow("")
    val watchSummary = _watchSummary.asStateFlow()

    @Volatile
    var pendingAction: AgentAction? = null

    @Volatile
    var continuousVoice: Boolean = false

    @Volatile
    var conversationOpen: Boolean = false

    fun updateThought(value: AgentThought) {
        pendingAction = value.action
        _thought.value = value
    }

    fun updateCurrentPackage(value: String?) {
        if (!value.isNullOrBlank()) _currentPackage.value = value
    }

    fun updateWatching(value: Boolean) {
        _watching.value = value
    }

    fun updateAiStatus(value: String) {
        _aiStatus.value = value
    }

    fun updateWatchSummary(value: String) {
        _watchSummary.value = value
    }
}
