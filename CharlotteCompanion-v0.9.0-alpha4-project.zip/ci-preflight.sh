#!/usr/bin/env bash
set -euo pipefail

test -f gradle.properties
grep -q "android.useAndroidX=true" gradle.properties

test -f app/src/main/AndroidManifest.xml
test -f app/src/main/java/com/charlotte/companion/agent/CharlotteAgentLoop.kt
test -f app/src/main/java/com/charlotte/companion/agent/PromptComposer.kt
test -f app/src/main/java/com/charlotte/companion/overlay/OverlayBubbleService.kt
test -f app/src/main/java/com/charlotte/companion/overlay/ConversationOverlayService.kt
test -f app/src/main/java/com/charlotte/companion/remote/AiGatewayClient.kt
test -f app/src/main/java/com/charlotte/companion/watch/ScreenWatchService.kt

grep -q 'applicationId = "com.charlotte.companion"' app/build.gradle.kts
grep -q 'versionName = "0.9.0-alpha4"' app/build.gradle.kts
grep -q 'openai/gpt-5.6-luna' app/src/main/java/com/charlotte/companion/prefs/CharlottePrefs.kt
grep -q 'openai/gpt-5.6-sol' app/src/main/java/com/charlotte/companion/prefs/CharlottePrefs.kt

echo "PRECHECK=PASS"
