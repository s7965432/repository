# 夏洛特共用手機模式 v0.9.0-alpha5

alpha5 移除 Vercel AI Gateway 依賴，改成 Android App 直接連 Google Gemini Developer API。

## 免費模型配置
- 常駐視線：`gemini-2.5-flash-lite`
- 深入對話：`gemini-2.5-flash`

兩者目前官方都有免費方案並支援圖片輸入。

## 保留功能
- 持續觀看手機畫面
- `？ / ！ / … / 表情` 主動提示
- 單次與連續語音對話
- 使用者說話可打斷 TTS
- 最近對話與明確偏好本機記憶
- Accessibility 點擊 / 滑動 / 返回 / Home
- 使用者正在碰手機時自動讓位
- 自動模式只直接執行低風險動作

## 金鑰
使用 Google AI Studio 建立 Gemini API Key。此版本完全不需要 Vercel Key。
