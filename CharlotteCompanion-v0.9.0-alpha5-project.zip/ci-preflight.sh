#!/usr/bin/env bash
set -euo pipefail

test -f gradle.properties
grep -q "android.useAndroidX=true" gradle.properties

test -f app/src/main/AndroidManifest.xml
test -f app/src/main/java/com/charlotte/companion/agent/CharlotteAgentLoop.kt
test -f app/src/main/java/com/charlotte/companion/remote/AiGatewayClient.kt
test -f app/src/main/java/com/charlotte/companion/overlay/ConversationOverlayService.kt

grep -q 'applicationId = "com.charlotte.companion"' app/build.gradle.kts
grep -q 'versionName = "0.9.0-alpha5"' app/build.gradle.kts
grep -q 'gemini-2.5-flash-lite' app/src/main/java/com/charlotte/companion/prefs/CharlottePrefs.kt
grep -q 'gemini-2.5-flash' app/src/main/java/com/charlotte/companion/prefs/CharlottePrefs.kt
grep -q 'generativelanguage.googleapis.com' app/src/main/java/com/charlotte/companion/remote/AiGatewayClient.kt
! grep -R 'ai-gateway.vercel.sh' app/src/main/java

echo PRECHECK=PASS
