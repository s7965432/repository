package com.charlotte.companion.remote

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class AiGatewayClient(private val apiKey: String) {

    fun respond(
        model: String,
        prompt: String,
        jpegBase64: String,
        maxOutputTokens: Int = 500
    ): String {
        val connection = URL(
            "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
        ).openConnection() as HttpURLConnection

        connection.requestMethod = "POST"
        connection.connectTimeout = 15000
        connection.readTimeout = 45000
        connection.doOutput = true
        connection.setRequestProperty("x-goog-api-key", apiKey)
        connection.setRequestProperty("Content-Type", "application/json")
        connection.setRequestProperty("Accept", "application/json")

        val parts = JSONArray()
            .put(JSONObject().put("text", prompt))
            .put(
                JSONObject().put(
                    "inline_data",
                    JSONObject()
                        .put("mime_type", "image/jpeg")
                        .put("data", jpegBase64)
                )
            )

        val body = JSONObject()
            .put(
                "contents",
                JSONArray().put(
                    JSONObject()
                        .put("role", "user")
                        .put("parts", parts)
                )
            )
            .put(
                "generationConfig",
                JSONObject()
                    .put("maxOutputTokens", maxOutputTokens)
                    .put("temperature", 0.5)
                    .put("responseMimeType", "application/json")
            )

        connection.outputStream.use {
            it.write(body.toString().toByteArray(Charsets.UTF_8))
        }

        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
        connection.disconnect()

        if (code !in 200..299) {
            throw IllegalStateException("Gemini HTTP $code: ${raw.take(500)}")
        }

        val root = JSONObject(raw)
        val candidates = root.optJSONArray("candidates") ?: JSONArray()
        if (candidates.length() == 0) {
            throw IllegalStateException("Gemini 沒有回傳候選內容")
        }

        val content = candidates.optJSONObject(0)?.optJSONObject("content")
            ?: throw IllegalStateException("Gemini 回覆缺少 content")
        val outParts = content.optJSONArray("parts") ?: JSONArray()

        val text = buildString {
            for (i in 0 until outParts.length()) {
                val t = outParts.optJSONObject(i)?.optString("text", "").orEmpty()
                if (t.isNotBlank()) append(t)
            }
        }.trim()

        if (text.isBlank()) throw IllegalStateException("Gemini 回覆沒有文字內容")
        return text
    }
}
