#!/usr/bin/env bash
set -euo pipefail
APK="app/build/outputs/apk/debug/app-debug.apk"
adb install -r "$APK"
adb logcat -c
adb shell am force-stop com.charlotte.agent
adb shell am start -W -n com.charlotte.agent/.MainActivity | tee activity-start.txt
sleep 5
PID="$(adb shell pidof com.charlotte.agent | tr -d '\r')"
if [ -z "$PID" ]; then
  adb logcat -d -v time | tee emulator-logcat.txt
  exit 1
fi
adb shell dumpsys activity activities | tee activity-state.txt
adb logcat -d -v time | tee emulator-logcat.txt
! grep -q "FATAL EXCEPTION" emulator-logcat.txt
grep -q "com.charlotte.agent/.MainActivity" activity-state.txt
echo "PASS"
