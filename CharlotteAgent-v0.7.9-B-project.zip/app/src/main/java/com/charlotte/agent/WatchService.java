package com.charlotte.agent;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;

public class WatchService extends Service {
    private static final String CHANNEL = "charlotte_watch";
    private static final int NOTIFICATION_ID = 901;

    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private Handler handler;

    private final MediaProjection.Callback projectionCallback =
        new MediaProjection.Callback() {
            @Override
            public void onStop() {
                releaseCapture();
                stopSelf();
            }
        };

    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());

        NotificationChannel channel = new NotificationChannel(
            CHANNEL, "夏洛特保持觀看", NotificationManager.IMPORTANCE_LOW
        );
        getSystemService(NotificationManager.class)
            .createNotificationChannel(channel);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(
            NOTIFICATION_ID,
            new Notification.Builder(this, CHANNEL)
                .setContentTitle("夏洛特正在保持觀看")
                .setContentText("畫面觀看服務執行中")
                .setSmallIcon(android.R.drawable.presence_video_online)
                .setOngoing(true)
                .build()
        );

        if (intent == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        try {
            int resultCode = intent.getIntExtra("resultCode", 0);
            Intent data = intent.getParcelableExtra("data");

            if (resultCode == 0 || data == null) {
                stopSelf();
                return START_NOT_STICKY;
            }

            MediaProjectionManager manager = (MediaProjectionManager)
                getSystemService(Context.MEDIA_PROJECTION_SERVICE);

            projection = manager.getMediaProjection(resultCode, data);

            if (projection == null) {
                stopSelf();
                return START_NOT_STICKY;
            }

            projection.registerCallback(projectionCallback, handler);

            DisplayMetrics m = getResources().getDisplayMetrics();
            imageReader = ImageReader.newInstance(
                m.widthPixels, m.heightPixels, PixelFormat.RGBA_8888, 3
            );

            imageReader.setOnImageAvailableListener(reader -> {
                Image image = null;
                try {
                    image = reader.acquireLatestImage();
                } catch (Throwable ignored) {
                } finally {
                    if (image != null) image.close();
                }
            }, handler);

            virtualDisplay = projection.createVirtualDisplay(
                "CharlotteWatch",
                m.widthPixels,
                m.heightPixels,
                m.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(),
                null,
                handler
            );
        } catch (Throwable t) {
            releaseCapture();
            stopSelf();
        }

        return START_NOT_STICKY;
    }

    private void releaseCapture() {
        if (virtualDisplay != null) {
            virtualDisplay.release();
            virtualDisplay = null;
        }

        if (imageReader != null) {
            imageReader.close();
            imageReader = null;
        }

        if (projection != null) {
            try {
                projection.unregisterCallback(projectionCallback);
            } catch (Throwable ignored) {}
            projection = null;
        }
    }

    @Override
    public void onDestroy() {
        releaseCapture();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
