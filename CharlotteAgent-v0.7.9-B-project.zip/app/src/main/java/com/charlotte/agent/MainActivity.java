package com.charlotte.agent;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int CAPTURE_REQUEST = 5001;
    private MediaProjectionManager projectionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        projectionManager = (MediaProjectionManager)
            getSystemService(Context.MEDIA_PROJECTION_SERVICE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(48, 48, 48, 48);

        TextView title = new TextView(this);
        title.setText("夏洛特 AI 代理遊戲器\nv0.7.9-B");
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);

        TextView status = new TextView(this);
        status.setText("\n代理器已啟動\n\n1. 開啟操作權限\n2. 開始保持觀看\n");
        status.setTextSize(18);
        status.setGravity(Gravity.CENTER);

        Button accessibility = new Button(this);
        accessibility.setText("開啟操作權限");
        accessibility.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            } catch (Throwable t) {
                Toast.makeText(this, "無法開啟操作權限", Toast.LENGTH_LONG).show();
            }
        });

        Button watch = new Button(this);
        watch.setText("開始保持觀看");
        watch.setOnClickListener(v -> {
            try {
                if (projectionManager == null) {
                    Toast.makeText(this, "系統不支援畫面擷取", Toast.LENGTH_LONG).show();
                    return;
                }
                startActivityForResult(
                    projectionManager.createScreenCaptureIntent(),
                    CAPTURE_REQUEST
                );
            } catch (Throwable t) {
                Toast.makeText(this,
                    "無法開啟畫面觀看：" + t.getClass().getSimpleName(),
                    Toast.LENGTH_LONG).show();
            }
        });

        Button stop = new Button(this);
        stop.setText("停止觀看");
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, WatchService.class));
            Toast.makeText(this, "已停止觀看", Toast.LENGTH_SHORT).show();
        });

        root.addView(title);
        root.addView(status);
        root.addView(accessibility);
        root.addView(watch);
        root.addView(stop);
        setContentView(root);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode != CAPTURE_REQUEST) return;

        if (resultCode != RESULT_OK || data == null) {
            Toast.makeText(this, "已取消保持觀看", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            Intent service = new Intent(this, WatchService.class);
            service.putExtra("resultCode", resultCode);
            service.putExtra("data", data);
            startForegroundService(service);
            Toast.makeText(this, "夏洛特開始保持觀看", Toast.LENGTH_LONG).show();
        } catch (Throwable t) {
            Toast.makeText(this,
                "觀看服務啟動失敗：" + t.getClass().getSimpleName(),
                Toast.LENGTH_LONG).show();
        }
    }
}
