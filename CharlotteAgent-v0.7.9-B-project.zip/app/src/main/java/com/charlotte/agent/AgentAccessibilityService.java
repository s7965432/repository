package com.charlotte.agent;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.view.accessibility.AccessibilityEvent;

public class AgentAccessibilityService extends AccessibilityService {
    private static AgentAccessibilityService instance;
    private String currentPackage = "";

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event != null && event.getPackageName() != null) {
            currentPackage = event.getPackageName().toString();
        }
    }

    @Override
    public void onInterrupt() {}

    @Override
    public void onDestroy() {
        if (instance == this) instance = null;
        super.onDestroy();
    }

    public static AgentAccessibilityService getInstance() { return instance; }

    public boolean tap(float x, float y) {
        Path p = new Path();
        p.moveTo(x, y);
        GestureDescription.StrokeDescription s =
            new GestureDescription.StrokeDescription(p, 0, 60);
        return dispatchGesture(
            new GestureDescription.Builder().addStroke(s).build(),
            null, null
        );
    }

    public boolean swipe(float sx, float sy, float ex, float ey, long duration) {
        Path p = new Path();
        p.moveTo(sx, sy);
        p.lineTo(ex, ey);
        GestureDescription.StrokeDescription s =
            new GestureDescription.StrokeDescription(p, 0, duration);
        return dispatchGesture(
            new GestureDescription.Builder().addStroke(s).build(),
            null, null
        );
    }

    public String getCurrentPackage() { return currentPackage; }
}
