plugins { id("com.android.application") }
android {
    namespace = "com.charlotte.agent"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.charlotte.agent"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.7.9-B"
    }
}
