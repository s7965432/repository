package com.charlotte.companion.remote

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class AiGatewayClient(private val apiKey: String) {

    fun analyze(prompt: String, jpegBase64: String): String {
        val connection = (URL("https://ai-gateway.vercel.sh/v1/responses").openConnection() as HttpURLConnection)
        connection.requestMethod = "POST"
        connection.connectTimeout = 15000
        connection.readTimeout = 30000
        connection.doOutput = true
        connection.setRequestProperty("Authorization", "Bearer $apiKey")
        connection.setRequestProperty("Content-Type", "application/json")

        val content = JSONArray()
            .put(JSONObject().put("type", "input_text").put("text", prompt))
            .put(JSONObject()
                .put("type", "input_image")
                .put("image_url", "data:image/jpeg;base64,$jpegBase64")
                .put("detail", "low"))

        val input = JSONArray().put(
            JSONObject()
                .put("type", "message")
                .put("role", "user")
                .put("content", content)
        )

        val body = JSONObject()
            .put("model", "openai/gpt-5.6-sol")
            .put("input", input)

        connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val raw = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        connection.disconnect()

        if (code !in 200..299) throw IllegalStateException("AI Gateway HTTP $code: $raw")

        val root = JSONObject(raw)
        val output = root.optJSONArray("output") ?: JSONArray()
        for (i in 0 until output.length()) {
            val item = output.optJSONObject(i) ?: continue
            val parts = item.optJSONArray("content") ?: continue
            for (j in 0 until parts.length()) {
                val part = parts.optJSONObject(j) ?: continue
                val text = part.optString("text", "")
                if (text.isNotBlank()) return text
            }
        }
        throw IllegalStateException("AI 回覆沒有文字內容")
    }
}
