# 夏洛特共用手機模式 v0.9.0-alpha3

這版把「夏洛特持續觀看 + 永久懸浮 + 主動提問 + 語音對話 + 輔助操作」放進同一個 Android 工程。

## 已實作
- MediaProjection 持續觀看
- Android 14+ MediaProjection callback 修正
- 螢幕方向改變後重建擷取 Surface
- 畫面取樣轉 JPEG/Base64
- Vercel AI Gateway 視覺請求
- GPT-5.6 Sol 畫面理解
- 懸浮夏洛特，可拖動
- `？` `！` `…` / emoji 狀態
- 點懸浮顯示夏洛特訊息
- SpeechRecognizer 語音輸入
- Android TTS 語音輸出，可被使用者打斷
- 最近對話與使用者明確偏好本機記憶
- Accessibility 點擊 / 滑動 / 返回 / Home
- 觀察 / 輔助 / 自動模式
- 自動模式只自動執行 AI 標記為 low-risk 的操作
- 高風險操作保留人工確認

## 還不是最終版
- AI 座標判斷仍需真機修正
- 長時間續航 / 背景回收需實機驗證
- 還沒加入完整多點觸控手勢與鍵盤輸入
- 語音目前使用 Android 系統 SpeechRecognizer / TTS
- 「記憶」目前是本機簡易持久化，不是完整長期人物模型

## alpha3 修正
- 啟用 AndroidX，修正 GitHub Actions 的依賴解析失敗。
- 修正 AI Gateway 回應讀取。
- 懸浮服務加入 Android 14+ specialUse 前景服務類型。
