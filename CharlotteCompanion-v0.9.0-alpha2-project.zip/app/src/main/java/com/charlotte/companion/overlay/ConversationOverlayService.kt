package com.charlotte.companion.overlay

import android.Manifest
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.os.Bundle
import android.os.IBinder
import android.speech.*
import android.view.Gravity
import android.view.WindowManager
import android.widget.*
import androidx.core.content.ContextCompat
import com.charlotte.companion.agent.CharlotteAgentLoop
import com.charlotte.companion.model.ActionType
import com.charlotte.companion.state.CharlotteStateStore
import com.charlotte.companion.voice.SpeechOutputController
import kotlinx.coroutines.*

class ConversationOverlayService : Service(), RecognitionListener {

    private lateinit var windowManager: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var messageView: TextView
    private lateinit var micButton: Button
    private lateinit var actionButton: Button
    private var recognizer: SpeechRecognizer? = null
    private lateinit var speech: SpeechOutputController
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var lastSpokenMessage = ""

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        speech = SpeechOutputController(this)

        messageView = TextView(this).apply {
            text = "夏洛特：${CharlotteStateStore.thought.value.message}"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 0, 0, 12)
        }

        micButton = Button(this).apply {
            text = "🎙 語音回答"
            setOnClickListener { startVoice() }
        }

        actionButton = Button(this).apply {
            text = "讓夏洛特做"
            setOnClickListener {
                val action = CharlotteStateStore.pendingAction
                if (action == null || action.type == ActionType.NONE) {
                    Toast.makeText(this@ConversationOverlayService, "目前沒有待執行動作", Toast.LENGTH_SHORT).show()
                } else {
                    val ok = CharlotteAgentLoop.executePendingAction(applicationContext)
                    Toast.makeText(
                        this@ConversationOverlayService,
                        if (ok) "已執行" else "操作權限尚未啟用",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

        val close = Button(this).apply {
            text = "縮回夏洛特"
            setOnClickListener { stopSelf() }
        }

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
            setBackgroundColor(0xEE151515.toInt())
            addView(messageView)
            addView(micButton)
            addView(actionButton)
            addView(close)
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM
        }

        windowManager.addView(root, params)

        scope.launch {
            CharlotteStateStore.thought.collect { thought ->
                messageView.text = "夏洛特：${thought.message}"
                actionButton.isEnabled = thought.action?.type != null && thought.action.type != ActionType.NONE
                if (thought.speak && thought.message != lastSpokenMessage) {
                    lastSpokenMessage = thought.message
                    speech.speak(thought.message)
                }
            }
        }
    }

    private fun startVoice() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            messageView.text = "夏洛特：先回主畫面允許麥克風權限，我才能聽你說話。"
            return
        }

        speech.interrupt()

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            messageView.text = "夏洛特：這支手機目前沒有可用的語音辨識服務。"
            return
        }

        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
                it.setRecognitionListener(this)
            }
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "zh-TW")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        micButton.text = "正在聽…"
        recognizer?.startListening(intent)
    }

    override fun onReadyForSpeech(params: Bundle?) {
        micButton.text = "我在聽"
    }

    override fun onBeginningOfSpeech() = Unit
    override fun onRmsChanged(rmsdB: Float) = Unit
    override fun onBufferReceived(buffer: ByteArray?) = Unit
    override fun onEndOfSpeech() { micButton.text = "處理中…" }

    override fun onError(error: Int) {
        micButton.text = "🎙 語音回答"
        messageView.text = "夏洛特：剛剛沒聽清楚，再說一次。"
    }

    override fun onResults(results: Bundle?) {
        micButton.text = "🎙 語音回答"
        val text = results
            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            ?.firstOrNull()
            .orEmpty()
        if (text.isNotBlank()) {
            messageView.text = "你：$text\n\n夏洛特：我在想。"
            CharlotteAgentLoop.onUserVoice(applicationContext, text)
        }
    }

    override fun onPartialResults(partialResults: Bundle?) {
        val partial = partialResults
            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            ?.firstOrNull()
            .orEmpty()
        if (partial.isNotBlank()) messageView.text = "你：$partial"
    }

    override fun onEvent(eventType: Int, params: Bundle?) = Unit

    override fun onDestroy() {
        scope.cancel()
        recognizer?.destroy()
        speech.shutdown()
        runCatching { windowManager.removeView(root) }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
