package com.charlotte.companion.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

class SpeechOutputController(context: Context) : TextToSpeech.OnInitListener {
    private val tts = TextToSpeech(context.applicationContext, this)
    @Volatile private var ready = false

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale.TAIWAN
            tts.setSpeechRate(1.02f)
            ready = true
        }
    }

    fun speak(text: String) {
        if (!ready || text.isBlank()) return
        tts.stop()
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "charlotte")
    }

    fun interrupt() = tts.stop()
    fun shutdown() = tts.shutdown()
}
