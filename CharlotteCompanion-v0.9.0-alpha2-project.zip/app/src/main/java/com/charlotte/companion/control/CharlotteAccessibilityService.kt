package com.charlotte.companion.control

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import com.charlotte.companion.model.ActionType
import com.charlotte.companion.model.AgentAction
import com.charlotte.companion.state.CharlotteStateStore

class CharlotteAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: CharlotteAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        CharlotteStateStore.updateCurrentPackage(event?.packageName?.toString())
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    fun execute(action: AgentAction): Boolean {
        return when (action.type) {
            ActionType.NONE -> false
            ActionType.TAP -> tapNormalized(action.x, action.y)
            ActionType.SWIPE -> swipeNormalized(action.x, action.y, action.x2, action.y2, action.durationMs)
            ActionType.BACK -> performGlobalAction(GLOBAL_ACTION_BACK)
            ActionType.HOME -> performGlobalAction(GLOBAL_ACTION_HOME)
        }
    }

    private fun tapNormalized(nx: Float, ny: Float): Boolean {
        val dm = resources.displayMetrics
        val x = nx.coerceIn(0f, 1f) * dm.widthPixels
        val y = ny.coerceIn(0f, 1f) * dm.heightPixels
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 80)
        return dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    private fun swipeNormalized(
        nx1: Float, ny1: Float, nx2: Float, ny2: Float, duration: Long
    ): Boolean {
        val dm = resources.displayMetrics
        val path = Path().apply {
            moveTo(nx1.coerceIn(0f, 1f) * dm.widthPixels, ny1.coerceIn(0f, 1f) * dm.heightPixels)
            lineTo(nx2.coerceIn(0f, 1f) * dm.widthPixels, ny2.coerceIn(0f, 1f) * dm.heightPixels)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, duration.coerceIn(80, 3000))
        return dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }
}
