package com.charlotte.companion.memory

import android.content.Context
import com.charlotte.companion.model.MemoryTurn
import org.json.JSONArray
import org.json.JSONObject

object MemoryStore {
    private const val PREFS = "charlotte_memory"
    private const val KEY_TURNS = "turns"
    private const val KEY_NOTES = "notes"
    private const val MAX_TURNS = 80
    private const val MAX_NOTES = 40

    fun addTurn(context: Context, who: String, text: String) {
        if (text.isBlank()) return
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = runCatching { JSONArray(prefs.getString(KEY_TURNS, "[]")) }.getOrElse { JSONArray() }
        arr.put(JSONObject()
            .put("who", who)
            .put("text", text)
            .put("timestamp", System.currentTimeMillis()))
        while (arr.length() > MAX_TURNS) {
            val next = JSONArray()
            for (i in 1 until arr.length()) next.put(arr.get(i))
            prefs.edit().putString(KEY_TURNS, next.toString()).apply()
            return
        }
        prefs.edit().putString(KEY_TURNS, arr.toString()).apply()
    }

    fun addNote(context: Context, note: String) {
        if (note.isBlank()) return
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = runCatching { JSONArray(prefs.getString(KEY_NOTES, "[]")) }.getOrElse { JSONArray() }
        for (i in 0 until arr.length()) {
            if (arr.optString(i) == note) return
        }
        arr.put(note)
        while (arr.length() > MAX_NOTES) {
            val next = JSONArray()
            for (i in 1 until arr.length()) next.put(arr.get(i))
            prefs.edit().putString(KEY_NOTES, next.toString()).apply()
            return
        }
        prefs.edit().putString(KEY_NOTES, arr.toString()).apply()
    }

    fun recentContext(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val turns = runCatching { JSONArray(prefs.getString(KEY_TURNS, "[]")) }.getOrElse { JSONArray() }
        val notes = runCatching { JSONArray(prefs.getString(KEY_NOTES, "[]")) }.getOrElse { JSONArray() }

        val sb = StringBuilder()
        if (notes.length() > 0) {
            sb.append("已確認偏好/記憶：\n")
            for (i in 0 until notes.length()) sb.append("- ").append(notes.optString(i)).append('\n')
        }
        if (turns.length() > 0) {
            sb.append("最近對話：\n")
            val start = (turns.length() - 14).coerceAtLeast(0)
            for (i in start until turns.length()) {
                val o = turns.optJSONObject(i) ?: continue
                sb.append(o.optString("who")).append("：")
                    .append(o.optString("text")).append('\n')
            }
        }
        return sb.toString()
    }
}
