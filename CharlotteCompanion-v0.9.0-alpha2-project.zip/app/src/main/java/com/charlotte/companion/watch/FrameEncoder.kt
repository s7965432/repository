package com.charlotte.companion.watch

import android.graphics.Bitmap
import android.media.Image
import android.util.Base64
import java.io.ByteArrayOutputStream

object FrameEncoder {
    fun toJpegBase64(image: Image, maxWidth: Int = 720, quality: Int = 68): String? {
        return runCatching {
            val plane = image.planes.first()
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * image.width
            val paddedWidth = image.width + rowPadding / pixelStride

            val padded = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
            padded.copyPixelsFromBuffer(buffer)

            val cropped = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
            if (padded !== cropped) padded.recycle()

            val finalBitmap = if (cropped.width > maxWidth) {
                val h = (cropped.height * (maxWidth.toFloat() / cropped.width)).toInt().coerceAtLeast(1)
                val scaled = Bitmap.createScaledBitmap(cropped, maxWidth, h, true)
                if (scaled !== cropped) cropped.recycle()
                scaled
            } else cropped

            val out = ByteArrayOutputStream()
            finalBitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)
            finalBitmap.recycle()
            Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        }.getOrNull()
    }
}
