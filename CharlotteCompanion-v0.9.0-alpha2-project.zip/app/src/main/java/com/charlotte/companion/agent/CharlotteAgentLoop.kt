package com.charlotte.companion.agent

import android.content.Context
import com.charlotte.companion.control.CharlotteAccessibilityService
import com.charlotte.companion.memory.MemoryStore
import com.charlotte.companion.model.*
import com.charlotte.companion.prefs.CharlottePrefs
import com.charlotte.companion.remote.AiGatewayClient
import com.charlotte.companion.state.CharlotteStateStore
import kotlinx.coroutines.*
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicBoolean

object CharlotteAgentLoop {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val busy = AtomicBoolean(false)

    @Volatile private var latestFrameBase64: String? = null
    @Volatile private var lastAnalysisAt = 0L
    @Volatile private var warnedNoKey = false

    fun onFrame(context: Context, jpegBase64: String) {
        latestFrameBase64 = jpegBase64
        val now = System.currentTimeMillis()
        if (now - lastAnalysisAt < 2500) return
        lastAnalysisAt = now
        analyze(context.applicationContext, null)
    }

    fun onUserVoice(context: Context, text: String) {
        if (text.isBlank()) return
        MemoryStore.addTurn(context, "使用者", text)
        analyze(context.applicationContext, text)
    }

    fun executePendingAction(context: Context): Boolean {
        val action = CharlotteStateStore.pendingAction ?: return false
        val ok = CharlotteAccessibilityService.instance?.execute(action) ?: false
        if (ok) {
            CharlotteStateStore.updateThought(
                AgentThought("…", "好，我做了。現在看結果。", false, null, null)
            )
        }
        return ok
    }

    private fun analyze(context: Context, userText: String?) {
        val frame = latestFrameBase64 ?: return
        if (!busy.compareAndSet(false, true)) return

        scope.launch {
            try {
                val key = CharlottePrefs.getGatewayKey(context)
                if (key.isBlank()) {
                    if (!warnedNoKey) {
                        warnedNoKey = true
                        CharlotteStateStore.updateThought(
                            AgentThought(
                                symbol = "？",
                                message = "我已經在持續看畫面了，但還沒連上 AI。把 AI Gateway Key 存進主畫面，我才能真正理解你正在做什麼。",
                                speak = false
                            )
                        )
                    }
                    return@launch
                }

                warnedNoKey = false
                val mode = CharlottePrefs.getMode(context)
                val prompt = PromptComposer.build(context, mode, userText)
                val raw = AiGatewayClient(key).analyze(prompt, frame)
                val thought = parseThought(raw)

                MemoryStore.addTurn(context, "夏洛特", thought.message)
                thought.memoryNote?.takeIf { it.isNotBlank() }?.let { MemoryStore.addNote(context, it) }

                CharlotteStateStore.updateThought(thought)

                if (mode == AgentMode.AUTO) {
                    val action = thought.action
                    if (action != null && action.type != ActionType.NONE && action.risk == RiskLevel.LOW) {
                        delay(250)
                        CharlotteAccessibilityService.instance?.execute(action)
                    }
                }
            } catch (t: Throwable) {
                CharlotteStateStore.updateThought(
                    AgentThought(
                        symbol = "！",
                        message = "AI 連線剛剛出錯了：${t.message?.take(120) ?: "未知錯誤"}",
                        speak = false
                    )
                )
            } finally {
                busy.set(false)
            }
        }
    }

    private fun parseThought(raw: String): AgentThought {
        val cleaned = raw.trim()
            .removePrefix("```json").removePrefix("```")
            .removeSuffix("```").trim()

        val o = JSONObject(cleaned)
        val actionObj = o.optJSONObject("action")
        val action = if (actionObj == null) null else {
            val type = when (actionObj.optString("type", "none").lowercase()) {
                "tap" -> ActionType.TAP
                "swipe" -> ActionType.SWIPE
                "back" -> ActionType.BACK
                "home" -> ActionType.HOME
                else -> ActionType.NONE
            }
            val risk = when (actionObj.optString("risk", "low").lowercase()) {
                "high" -> RiskLevel.HIGH
                "medium" -> RiskLevel.MEDIUM
                else -> RiskLevel.LOW
            }
            AgentAction(
                type = type,
                x = actionObj.optDouble("x", 0.0).toFloat(),
                y = actionObj.optDouble("y", 0.0).toFloat(),
                x2 = actionObj.optDouble("x2", 0.0).toFloat(),
                y2 = actionObj.optDouble("y2", 0.0).toFloat(),
                durationMs = actionObj.optLong("duration_ms", 250),
                risk = risk
            )
        }

        return AgentThought(
            symbol = o.optString("symbol", "夏").take(2),
            message = o.optString("message", "我在看。").take(800),
            speak = o.optBoolean("speak", false),
            action = action,
            memoryNote = if (o.isNull("memory_note")) null else o.optString("memory_note", null)
        )
    }
}
