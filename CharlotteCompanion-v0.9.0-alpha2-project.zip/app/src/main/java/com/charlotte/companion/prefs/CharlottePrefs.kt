package com.charlotte.companion.prefs

import android.content.Context
import com.charlotte.companion.model.AgentMode

object CharlottePrefs {
    private const val NAME = "charlotte_prefs"
    private const val KEY_GATEWAY = "gateway_key"
    private const val KEY_MODE = "agent_mode"

    fun setGatewayKey(context: Context, key: String) {
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_GATEWAY, key.trim()).apply()
    }

    fun getGatewayKey(context: Context): String =
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .getString(KEY_GATEWAY, "") ?: ""

    fun setMode(context: Context, mode: AgentMode) {
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_MODE, mode.name).apply()
    }

    fun getMode(context: Context): AgentMode {
        val raw = context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .getString(KEY_MODE, AgentMode.ASSIST.name)
        return runCatching { AgentMode.valueOf(raw ?: AgentMode.ASSIST.name) }
            .getOrDefault(AgentMode.ASSIST)
    }
}
