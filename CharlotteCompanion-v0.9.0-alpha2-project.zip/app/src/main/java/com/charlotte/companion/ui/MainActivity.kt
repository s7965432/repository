package com.charlotte.companion.ui

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.charlotte.companion.databinding.ActivityMainBinding
import com.charlotte.companion.model.AgentMode
import com.charlotte.companion.overlay.OverlayBubbleService
import com.charlotte.companion.prefs.CharlottePrefs
import com.charlotte.companion.voice.SpeechOutputController
import com.charlotte.companion.watch.ScreenWatchService

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var projectionManager: MediaProjectionManager
    private lateinit var speech: SpeechOutputController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        speech = SpeechOutputController(this)

        binding.etGateway.setText(CharlottePrefs.getGatewayKey(this))
        when (CharlottePrefs.getMode(this)) {
            AgentMode.OBSERVE -> binding.modeObserve.isChecked = true
            AgentMode.ASSIST -> binding.modeAssist.isChecked = true
            AgentMode.AUTO -> binding.modeAuto.isChecked = true
        }

        requestRuntimePermissions()

        binding.btnOverlay.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                ))
                binding.tvStatus.text = "狀態：請允許「顯示在其他應用程式上層」後再按一次"
            } else {
                ContextCompat.startForegroundService(this, Intent(this, OverlayBubbleService::class.java))
                binding.tvStatus.text = "狀態：懸浮夏洛特已啟動"
            }
        }

        binding.btnWatch.setOnClickListener {
            startActivityForResult(projectionManager.createScreenCaptureIntent(), 1001)
        }

        binding.btnAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        binding.btnSaveGateway.setOnClickListener {
            CharlottePrefs.setGatewayKey(this, binding.etGateway.text?.toString().orEmpty())
            Toast.makeText(this, "AI 連線已儲存", Toast.LENGTH_SHORT).show()
        }

        binding.modeGroup.setOnCheckedChangeListener { _, checkedId ->
            val mode = when (checkedId) {
                binding.modeObserve.id -> AgentMode.OBSERVE
                binding.modeAuto.id -> AgentMode.AUTO
                else -> AgentMode.ASSIST
            }
            CharlottePrefs.setMode(this, mode)
        }

        binding.btnVoiceDemo.setOnClickListener {
            speech.speak("我在。之後你不用一直打字，直接對我說就好。")
        }
    }

    private fun requestRuntimePermissions() {
        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            needed += Manifest.permission.RECORD_AUDIO
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            needed += Manifest.permission.POST_NOTIFICATIONS
        }
        if (needed.isNotEmpty()) requestPermissions(needed.toTypedArray(), 2001)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == Activity.RESULT_OK && data != null) {
            val serviceIntent = Intent(this, ScreenWatchService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("data", data)
            }
            ContextCompat.startForegroundService(this, serviceIntent)
            binding.tvStatus.text = "狀態：保持觀看中"
        } else if (requestCode == 1001) {
            Toast.makeText(this, "你取消了保持觀看", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        speech.shutdown()
        super.onDestroy()
    }
}
