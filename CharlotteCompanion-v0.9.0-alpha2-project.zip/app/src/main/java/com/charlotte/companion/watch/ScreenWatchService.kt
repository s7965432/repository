package com.charlotte.companion.watch

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import com.charlotte.companion.agent.CharlotteAgentLoop
import com.charlotte.companion.state.CharlotteStateStore

class ScreenWatchService : Service() {

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private lateinit var captureThread: HandlerThread
    private lateinit var captureHandler: Handler
    private var frameIndex = 0

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            CharlotteStateStore.updateWatching(false)
            stopSelf()
        }
    }

    override fun onCreate() {
        super.onCreate()
        captureThread = HandlerThread("CharlotteCapture").apply { start() }
        captureHandler = Handler(captureThread.looper)

        val channel = NotificationChannel("charlotte_watch", "夏洛特持續觀看", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(
            10,
            Notification.Builder(this, "charlotte_watch")
                .setContentTitle("夏洛特正在持續觀看")
                .setContentText("共用手機模式運作中")
                .setSmallIcon(android.R.drawable.presence_video_online)
                .build()
        )

        val resultCode = intent?.getIntExtra("resultCode", 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra("data", Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra<Intent>("data")
        }

        if (resultCode == 0 || data == null) return START_NOT_STICKY

        releaseCapture()

        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data).also {
            it.registerCallback(projectionCallback, captureHandler)
        }

        createCaptureSurface()
        CharlotteStateStore.updateWatching(true)
        return START_STICKY
    }

    private fun createCaptureSurface() {
        display?.release()
        imageReader?.close()

        val dm = resources.displayMetrics
        imageReader = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 2)

        imageReader?.setOnImageAvailableListener({ reader ->
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                frameIndex++
                if (frameIndex % 10 == 0) {
                    FrameEncoder.toJpegBase64(image)?.let {
                        CharlotteAgentLoop.onFrame(applicationContext, it)
                    }
                }
            } finally {
                image.close()
            }
        }, captureHandler)

        display = projection?.createVirtualDisplay(
            "CharlotteWatch",
            dm.widthPixels,
            dm.heightPixels,
            dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            captureHandler
        )
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        captureHandler.postDelayed({ createCaptureSurface() }, 250)
    }

    private fun releaseCapture() {
        display?.release()
        display = null
        imageReader?.close()
        imageReader = null

        projection?.let {
            runCatching { it.unregisterCallback(projectionCallback) }
            runCatching { it.stop() }
        }
        projection = null
    }

    override fun onDestroy() {
        CharlotteStateStore.updateWatching(false)
        releaseCapture()
        if (::captureThread.isInitialized) captureThread.quitSafely()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
