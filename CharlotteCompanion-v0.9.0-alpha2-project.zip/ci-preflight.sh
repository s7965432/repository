#!/usr/bin/env bash
set -euo pipefail
test -f app/src/main/AndroidManifest.xml
test -f app/src/main/java/com/charlotte/companion/overlay/OverlayBubbleService.kt
test -f app/src/main/java/com/charlotte/companion/overlay/ConversationOverlayService.kt
test -f app/src/main/java/com/charlotte/companion/watch/ScreenWatchService.kt
test -f app/src/main/java/com/charlotte/companion/remote/AiGatewayClient.kt
grep -q 'applicationId = "com.charlotte.companion"' app/build.gradle.kts
grep -q 'versionName = "0.9.0-alpha2"' app/build.gradle.kts
echo "PRECHECK=PASS"
