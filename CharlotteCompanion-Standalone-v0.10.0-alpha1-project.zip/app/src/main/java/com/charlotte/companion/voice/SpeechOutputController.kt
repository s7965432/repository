package com.charlotte.companion.voice
import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

class SpeechOutputController(private val context:Context):TextToSpeech.OnInitListener{
    private val tts=TextToSpeech(context.applicationContext,this)
    private val callbacks=ConcurrentHashMap<String,()->Unit>()
    @Volatile private var ready=false
    init{
        tts.setOnUtteranceProgressListener(object:UtteranceProgressListener(){
            override fun onStart(id:String?)=Unit
            override fun onDone(id:String?){id?.let{callbacks.remove(it)?.invoke()}}
            @Deprecated("Deprecated in Java")
            override fun onError(id:String?){id?.let{callbacks.remove(it)?.invoke()}}
        })
    }
    override fun onInit(status:Int){
        if(status==TextToSpeech.SUCCESS){tts.language=Locale.TAIWAN;ready=true}
    }
    fun speak(text:String,onDone:(()->Unit)?=null){
        if(!ready||text.isBlank()){onDone?.invoke();return}
        val p=VoiceStyleProfileStore.load(context)
        tts.setPitch(p.pitchScale);tts.setSpeechRate(p.speechRate)
        tts.stop();val id="charlotte-${System.currentTimeMillis()}"
        if(onDone!=null)callbacks[id]=onDone
        tts.speak(text,TextToSpeech.QUEUE_FLUSH,Bundle(),id)
    }
    fun interrupt(){callbacks.clear();tts.stop()}
    fun shutdown(){callbacks.clear();tts.shutdown()}
}
