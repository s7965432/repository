#!/usr/bin/env bash
set -euo pipefail
test -f gradle.properties
grep -q "android.useAndroidX=true" gradle.properties
test -f app/src/main/java/com/charlotte/companion/voice/PlaybackVoiceLearner.kt
test -f app/src/main/java/com/charlotte/companion/voice/VoiceStyleAnalyzer.kt
grep -q 'applicationId = "com.charlotte.companion"' app/build.gradle.kts
grep -q 'versionName = "0.10.0-alpha1"' app/build.gradle.kts
grep -q 'btnStartVoiceLearning' app/src/main/res/layout/activity_main.xml
grep -q 'AudioPlaybackCaptureConfiguration' app/src/main/java/com/charlotte/companion/voice/PlaybackVoiceLearner.kt
echo "PRECHECK=PASS"
